import { createHmac, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { storeSettings } from "@/db/schema";

const COOKIE_NAME = "vexora_session";
const SESSION_AGE = 60 * 60 * 24 * 7;
const scryptAsync = promisify(scrypt);

export type VexoraSession = {
  role: "admin" | "customer";
  sub: string;
  name?: string;
  email?: string;
  exp: number;
};

async function getSigningSecret() {
  const configured = process.env.SESSION_SECRET || process.env.AUTH_SECRET || process.env.ADMIN_SESSION_SECRET;
  if (configured) return configured;

  const generated = randomBytes(32).toString("hex");
  await db.insert(storeSettings).values({ id: "store", sessionSecret: generated }).onConflictDoNothing();
  const [row] = await db.select({ secret: storeSettings.sessionSecret }).from(storeSettings).where(eq(storeSettings.id, "store")).limit(1);
  if (row?.secret) return row.secret;
  await db.update(storeSettings).set({ sessionSecret: generated }).where(eq(storeSettings.id, "store"));
  return generated;
}

function signature(payload: string, secret: string) {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export async function issueSession(session: Omit<VexoraSession, "exp">) {
  const secret = await getSigningSecret();
  const payload = Buffer.from(JSON.stringify({ ...session, exp: Math.floor(Date.now() / 1000) + SESSION_AGE })).toString("base64url");
  const token = `${payload}.${signature(payload, secret)}`;
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_AGE,
  });
}

export async function clearSession() {
  const jar = await cookies();
  jar.set(COOKIE_NAME, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 0 });
}

export async function getSession(): Promise<VexoraSession | null> {
  try {
    const token = (await cookies()).get(COOKIE_NAME)?.value;
    if (!token) return null;
    const [payload, providedSignature] = token.split(".");
    if (!payload || !providedSignature) return null;
    const expected = Buffer.from(signature(payload, await getSigningSecret()));
    const provided = Buffer.from(providedSignature);
    if (expected.length !== provided.length || !timingSafeEqual(expected, provided)) return null;
    const value = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as VexoraSession;
    if (!value.sub || !value.exp || value.exp <= Math.floor(Date.now() / 1000)) return null;
    if (value.role !== "admin" && value.role !== "customer") return null;
    return value;
  } catch {
    return null;
  }
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  try {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return false;
    const expected = Buffer.from(hash, "hex");
    const actual = (await scryptAsync(password, salt, expected.length)) as Buffer;
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export function normalizePhone(phone: string) {
  const arabicDigits = phone.replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
  return arabicDigits.replace(/[\s().-]/g, "");
}
