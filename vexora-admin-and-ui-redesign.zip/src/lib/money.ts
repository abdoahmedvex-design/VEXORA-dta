export function formatMoney(value: number | string, locale = "ar-EG") {
  return new Intl.NumberFormat(locale, { style: "currency", currency: "EGP", maximumFractionDigits: 2 }).format(Number(value) || 0);
}

export function toDecimal(value: unknown, fieldName = "السعر") {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0 || amount > 100000000) throw new Error(`${fieldName} غير صالح`);
  return amount.toFixed(2);
}
