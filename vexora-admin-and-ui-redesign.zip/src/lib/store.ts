import { and, asc, desc, eq, gte, lte } from "drizzle-orm";
import { db } from "@/db";
import { categories, exclusiveOffers, packages, products, storeSettings } from "@/db/schema";

export type PublicPackage = {
  id: string;
  legacyIndex: number;
  label: { ar: string; en: string };
  price: number;
  image: string | null;
  offer: null | {
    id: string;
    title: string;
    description: string;
    image: string | null;
    originalPrice: number;
    discountPrice: number;
    discountPercent: number;
    startsAt: string;
    endsAt: string;
  };
};

export type PublicProduct = {
  dbId: string;
  id: number;
  category: string;
  image: string | null;
  name: { ar: string; en: string };
  description: { ar: string; en: string };
  delivery: { ar: string; en: string };
  requiresPlayerId: boolean;
  packages: PublicPackage[];
};

export function imagePath(imageId: string | null | undefined, fallback?: string | null) {
  return imageId ? `/api/images/${imageId}` : fallback || null;
}

export async function getCatalog() {
  const now = new Date();
  const [categoryRows, productRows, packageRows, offerRows, settingsRows] = await Promise.all([
    db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.id)),
    db.select().from(products).where(eq(products.active, true)).orderBy(asc(products.sortOrder), asc(products.nameAr)),
    db.select().from(packages).where(eq(packages.active, true)).orderBy(asc(packages.sortOrder), asc(packages.legacyIndex)),
    db.select().from(exclusiveOffers).where(and(eq(exclusiveOffers.active, true), lte(exclusiveOffers.startsAt, now), gte(exclusiveOffers.endsAt, now))).orderBy(asc(exclusiveOffers.sortOrder), asc(exclusiveOffers.createdAt)),
    db.select({ tagline: storeSettings.tagline }).from(storeSettings).where(eq(storeSettings.id, "store")).limit(1),
  ]);

  const packageById = new Map(packageRows.map((item) => [item.id, item]));
  const productById = new Map(productRows.map((item) => [item.id, item]));
  const offersByPackage = new Map<string, typeof offerRows>();
  for (const offer of offerRows) {
    const current = offersByPackage.get(offer.packageId) || [];
    current.push(offer);
    offersByPackage.set(offer.packageId, current);
  }

  const publicProducts: PublicProduct[] = productRows.map((product) => {
    const productImage = imagePath(product.imageId || product.defaultImageId, product.fallbackImageUrl);
    const productPackages = packageRows.filter((item) => item.productId === product.id).map((item) => {
      const basePrice = Number(item.price);
      const activeOffer = (offersByPackage.get(item.id) || [])
        .filter((offer) => Number(offer.discountPrice) > 0 && Number(offer.discountPrice) < basePrice)
        .sort((a, b) => Number(a.discountPrice) - Number(b.discountPrice))[0];
      return {
        id: item.id,
        legacyIndex: item.legacyIndex,
        label: { ar: item.nameAr, en: item.nameEn },
        price: basePrice,
        image: imagePath(item.imageId, productImage),
        offer: activeOffer ? {
          id: activeOffer.id,
          title: activeOffer.title,
          description: activeOffer.description,
          image: imagePath(activeOffer.imageId, imagePath(item.imageId, productImage)),
          originalPrice: basePrice,
          discountPrice: Number(activeOffer.discountPrice),
          discountPercent: Math.max(0, Math.round((1 - Number(activeOffer.discountPrice) / basePrice) * 100)),
          startsAt: activeOffer.startsAt.toISOString(),
          endsAt: activeOffer.endsAt.toISOString(),
        } : null,
      } satisfies PublicPackage;
    });
    return {
      dbId: product.id,
      id: product.legacyId,
      category: product.categoryId,
      image: productImage,
      name: { ar: product.nameAr, en: product.nameEn },
      description: { ar: product.descriptionAr, en: product.descriptionEn },
      delivery: { ar: product.deliveryAr, en: product.deliveryEn },
      requiresPlayerId: product.requiresPlayerId,
      packages: productPackages,
    };
  });

  const publicOffers = offerRows.flatMap((offer) => {
    const product = productById.get(offer.productId);
    const item = packageById.get(offer.packageId);
    if (!product || !item || !product.active || !item.active) return [];
    const basePrice = Number(item.price);
    const discountPrice = Number(offer.discountPrice);
    if (!(discountPrice > 0 && discountPrice < basePrice)) return [];
    const productImage = imagePath(product.imageId || product.defaultImageId, product.fallbackImageUrl);
    return [{
      id: offer.id,
      title: offer.title,
      description: offer.description,
      productId: product.legacyId,
      packageIndex: item.legacyIndex,
      packageId: item.id,
      productName: product.nameAr,
      packageName: item.nameAr,
      image: imagePath(offer.imageId, imagePath(item.imageId, productImage)),
      originalPrice: basePrice,
      discountPrice,
      discountPercent: Math.max(0, Math.round((1 - discountPrice / basePrice) * 100)),
      startsAt: offer.startsAt.toISOString(),
      endsAt: offer.endsAt.toISOString(),
    }];
  });

  return {
    categories: categoryRows.map((item) => ({ id: item.id, icon: item.icon, name: { ar: item.nameAr, en: item.nameEn } })),
    products: publicProducts,
    offers: publicOffers,
    banner: { title: settingsRows[0]?.tagline || "عالمك الرقمي بمستوى أرقى", subtitle: "شحن ألعاب وبطاقات هدايا ومنتجات رقمية أصلية في مصر." },
  };
}

export async function getAdminProducts() {
  const [productRows, packageRows, categoryRows] = await Promise.all([
    db.select().from(products).orderBy(asc(products.sortOrder), asc(products.createdAt)),
    db.select().from(packages).orderBy(asc(packages.sortOrder), asc(packages.legacyIndex)),
    db.select().from(categories).orderBy(asc(categories.sortOrder)),
  ]);
  return productRows.map((product) => ({
    ...product,
    packages: packageRows.filter((item) => item.productId === product.id).map((item) => ({ ...item, price: Number(item.price) })),
    category: categoryRows.find((category) => category.id === product.categoryId) || null,
  }));
}

export async function getSafeStoreSettings() {
  const [settings] = await db.select().from(storeSettings).where(eq(storeSettings.id, "store")).limit(1);
  return {
    tagline: settings?.tagline || "عالمك الرقمي بمستوى أرقى",
    whatsappNumber: settings?.whatsappNumber || process.env.WHATSAPP_NUMBER || "",
    paymentDetails: settings?.paymentDetails || "",
  };
}

export async function getAdminOffers() {
  const [offerRows, productRows, packageRows] = await Promise.all([
    db.select().from(exclusiveOffers).orderBy(desc(exclusiveOffers.createdAt)),
    db.select().from(products),
    db.select().from(packages),
  ]);
  return offerRows.map((offer) => {
    const product = productRows.find((item) => item.id === offer.productId);
    const item = packageRows.find((pack) => pack.id === offer.packageId);
    return { ...offer, discountPrice: Number(offer.discountPrice), productName: product?.nameAr || "منتج محذوف", packageName: item?.nameAr || "باقة محذوفة", basePrice: Number(item?.price || 0) };
  });
}
