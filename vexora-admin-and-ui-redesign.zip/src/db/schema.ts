import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";

export const categories = pgTable("vexora_categories", {
  id: text("id").primaryKey(),
  icon: text("icon").notNull().default("✦"),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const mediaAssets = pgTable("vexora_media_assets", {
  id: uuid("id").defaultRandom().primaryKey(),
  mimeType: text("mime_type").notNull(),
  dataBase64: text("data_base64").notNull(),
  fileName: text("file_name").notNull().default("image"),
  size: integer("size").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const products = pgTable("vexora_products", {
  id: uuid("id").defaultRandom().primaryKey(),
  legacyId: integer("legacy_id").notNull().unique(),
  categoryId: text("category_id").notNull().references(() => categories.id, { onDelete: "restrict" }),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull().default(""),
  descriptionAr: text("description_ar").notNull().default(""),
  descriptionEn: text("description_en").notNull().default(""),
  deliveryAr: text("delivery_ar").notNull().default("تسليم سريع"),
  deliveryEn: text("delivery_en").notNull().default("Fast delivery"),
  requiresPlayerId: boolean("requires_player_id").notNull().default(false),
  imageId: uuid("image_id").references(() => mediaAssets.id, { onDelete: "set null" }),
  defaultImageId: uuid("default_image_id").references(() => mediaAssets.id, { onDelete: "set null" }),
  fallbackImageUrl: text("fallback_image_url"),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const packages = pgTable(
  "vexora_packages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    productId: uuid("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
    legacyIndex: integer("legacy_index").notNull(),
    nameAr: text("name_ar").notNull(),
    nameEn: text("name_en").notNull().default(""),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    imageId: uuid("image_id").references(() => mediaAssets.id, { onDelete: "set null" }),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [unique("vexora_package_product_legacy_index").on(table.productId, table.legacyIndex)],
);

export const exclusiveOffers = pgTable("vexora_exclusive_offers", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  productId: uuid("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  packageId: uuid("package_id").notNull().references(() => packages.id, { onDelete: "cascade" }),
  imageId: uuid("image_id").references(() => mediaAssets.id, { onDelete: "set null" }),
  discountPrice: numeric("discount_price", { precision: 12, scale: 2 }).notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const customers = pgTable("vexora_customers", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  email: text("email"),
  passwordHash: text("password_hash").notNull(),
  points: integer("points").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type OrderItemSnapshot = {
  productId: number;
  packageIndex: number;
  productName: string;
  packageName: string;
  image: string | null;
  quantity: number;
  playerId: string;
  unitPrice: number;
  originalPrice: number;
  offerTitle?: string;
};

export type OrderTimelineEntry = { status: string; at: string; note?: string };

export const orders = pgTable("vexora_orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  number: text("number").notNull().unique(),
  customerId: uuid("customer_id").references(() => customers.id, { onDelete: "set null" }),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  paymentMethod: text("payment_method").notNull(),
  status: text("status").notNull().default("received"),
  items: jsonb("items").$type<OrderItemSnapshot[]>().notNull(),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull(),
  offerDiscount: numeric("offer_discount", { precision: 12, scale: 2 }).notNull().default("0"),
  couponDiscount: numeric("coupon_discount", { precision: 12, scale: 2 }).notNull().default("0"),
  pointsDiscount: numeric("points_discount", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  pointsEarned: integer("points_earned").notNull().default(0),
  pointsRedeemed: integer("points_redeemed").notNull().default(0),
  pointsAwardedAt: timestamp("points_awarded_at", { withTimezone: true }),
  pointsRestoredAt: timestamp("points_restored_at", { withTimezone: true }),
  timeline: jsonb("timeline").$type<OrderTimelineEntry[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const coupons = pgTable("vexora_coupons", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  type: text("type").notNull().default("percent"),
  value: numeric("value", { precision: 12, scale: 2 }).notNull(),
  minPurchase: numeric("min_purchase", { precision: 12, scale: 2 }).notNull().default("0"),
  maxDiscount: numeric("max_discount", { precision: 12, scale: 2 }),
  categoryId: text("category_id").references(() => categories.id, { onDelete: "set null" }),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  active: boolean("active").notNull().default(true),
  maxUses: integer("max_uses"),
  usedCount: integer("used_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const storeSettings = pgTable("vexora_store_settings", {
  id: text("id").primaryKey().default("store"),
  tagline: text("tagline").notNull().default("عالمك الرقمي بمستوى أرقى"),
  whatsappNumber: text("whatsapp_number").notNull().default(""),
  paymentDetails: text("payment_details").notNull().default(""),
  sessionSecret: text("session_secret").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
