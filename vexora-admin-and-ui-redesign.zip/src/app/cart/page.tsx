import { CartPage } from "@/components/CartPage";

export const dynamic = "force-dynamic";

export default function CartRoute() { return <CartPage />; }
