import { redirect } from "next/navigation";
import { AdminDashboard } from "@/components/AdminDashboard";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  if ((await getSession())?.role !== "admin") redirect("/admin/login");
  return <AdminDashboard />;
}
