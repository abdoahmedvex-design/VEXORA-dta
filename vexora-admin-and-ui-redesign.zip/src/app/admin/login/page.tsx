import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { AdminLogin } from "@/components/AdminLogin";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if ((await getSession())?.role === "admin") redirect("/admin");
  return <AdminLogin />;
}
