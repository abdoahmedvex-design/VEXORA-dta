import { notFound } from "next/navigation";
import { ProductDetail } from "@/components/ProductDetail";
import { getCatalog } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ package?: string }> }) {
  const [{ id }, query, catalog] = await Promise.all([params, searchParams, getCatalog()]);
  const product = catalog.products.find((item) => String(item.id) === id);
  if (!product) notFound();
  return <ProductDetail product={product} initialPackageId={query.package} />;
}
