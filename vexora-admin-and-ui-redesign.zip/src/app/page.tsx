import { Storefront } from "@/components/Storefront";
import { getCatalog } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const catalog = await getCatalog();
  return <Storefront data={catalog} />;
}
