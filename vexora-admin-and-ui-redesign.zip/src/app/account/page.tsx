"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { formatMoney } from "@/lib/money";

type Customer = { id: string; name: string; phone: string; email?: string | null; points: number };
type Order = { number: string; status: string; total: number; createdAt: string; items: { productName: string; packageName: string; quantity: number }[] };

export default function AccountPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ name: "", phone: "", email: "", identifier: "", password: "" });
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    fetch("/api/auth/me").then((response) => response.json()).then((data) => { if (data.loggedIn && data.customer) { setCustomer(data.customer); setForm((current) => ({ ...current, name: data.customer.name, phone: data.customer.phone, email: data.customer.email || "" })); } }).catch(() => {});
  }, []);
  useEffect(() => {
    if (customer) fetch("/api/auth/orders").then((response) => response.ok ? response.json() : null).then((data) => { if (data?.orders) setOrders(data.orders); }).catch(() => {});
  }, [customer]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setSuccess("");
    try {
      const payload = mode === "register" ? { name: form.name, phone: form.phone, email: form.email, password: form.password } : { identifier: form.identifier, password: form.password };
      const response = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تسجيل الدخول.");
      setCustomer(data.customer); setSuccess(mode === "register" ? "تم إنشاء حسابك بنجاح." : "أهلاً بعودتك.");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر الاتصال. حاول مرة أخرى."); }
    finally { setBusy(false); }
  }

  async function signOut() {
    await fetch("/api/auth/logout", { method: "POST" }); setCustomer(null); setOrders([]); setSuccess("تم تسجيل الخروج.");
  }

  if (customer) return <div className="container page-shell">
    <div className="section-heading"><div><span className="eyebrow">YOUR VEXORA ACCOUNT</span><h2>مرحباً، {customer.name}</h2><p>تابع طلباتك ورصيد مكافآتك من مكان واحد.</p></div><button className="button button-quiet button-small" onClick={signOut}>تسجيل الخروج</button></div>
    {success && <p className="form-success">{success}</p>}
    <div className="stats-grid" style={{ maxWidth: 620 }}><div className="stat-card"><span>رصيد المكافآت</span><strong>{customer.points} <small style={{ fontSize: 11 }}>نقطة</small></strong></div><div className="stat-card"><span>رقم الهاتف</span><strong style={{ fontSize: 15, direction: "ltr", textAlign: "right" }}>{customer.phone}</strong></div></div>
    <section className="admin-panel"><div className="admin-panel-heading"><div><h2>طلباتك الأخيرة</h2><p>يظهر تحديث التتبع عند تسجيل رقم الطلب والهاتف.</p></div><Link href="/#tracking" className="button button-outline button-small">تتبّع طلب</Link></div>{orders.length ? <div className="admin-list">{orders.map((order) => <div key={order.number} className="admin-row"><div><strong>{order.number}</strong><small>{new Date(order.createdAt).toLocaleDateString("ar-EG")} · {order.items.length} عناصر</small></div><span className="status-badge">{statusLabel(order.status)}</span><strong>{formatMoney(order.total)}</strong><div className="admin-row-actions"><Link className="button button-quiet button-small" href={`/#tracking`}>تتبّع</Link></div></div>)}</div> : <div className="empty-panel">لا توجد طلبات مرتبطة بحسابك بعد.</div>}</section>
    <div style={{ marginTop: 18 }}><Link className="button button-gold" href="/#store">تصفّح المتجر</Link></div>
  </div>;

  return <div className="auth-wrap"><section className="auth-card" aria-labelledby="account-title">
    <div className="auth-brand"><span className="brand-mark">V</span><span className="brand-word">VEXORA<small>YOUR DIGITAL WORLD.</small></span></div>
    <h1 id="account-title">{mode === "login" ? "مرحباً بعودتك" : "أنشئ حسابك"}</h1>
    <p>سجّل الدخول لتتابع طلباتك ورصيد نقاط المكافآت.</p>
    <div className="auth-tabs"><button className={mode === "login" ? "active" : ""} type="button" onClick={() => { setMode("login"); setError(""); }}>تسجيل الدخول</button><button className={mode === "register" ? "active" : ""} type="button" onClick={() => { setMode("register"); setError(""); }}>حساب جديد</button></div>
    {error && <p className="form-error">{error}</p>}{success && <p className="form-success">{success}</p>}
    <form onSubmit={submit}>
      {mode === "register" && <><div className="field"><label className="form-label" htmlFor="name">الاسم الكامل</label><input id="name" className="input" autoComplete="name" required minLength={2} value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></div><div className="field"><label className="form-label" htmlFor="phone">رقم الهاتف</label><input id="phone" className="input" inputMode="tel" autoComplete="tel" required value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></div><div className="field"><label className="form-label" htmlFor="email">البريد الإلكتروني (اختياري)</label><input id="email" type="email" className="input" autoComplete="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /></div></>}
      {mode === "login" && <div className="field"><label className="form-label" htmlFor="identifier">رقم الهاتف أو البريد الإلكتروني</label><input id="identifier" className="input" autoComplete="username" required value={form.identifier} onChange={(event) => setForm({ ...form, identifier: event.target.value })} /></div>}
      <div className="field"><label className="form-label" htmlFor="password">كلمة المرور</label><div className="password-wrap"><input id="password" className="input" type={passwordVisible ? "text" : "password"} autoComplete={mode === "login" ? "current-password" : "new-password"} required minLength={mode === "register" ? 8 : undefined} value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} /><button type="button" className="password-toggle" onClick={() => setPasswordVisible((visible) => !visible)}>{passwordVisible ? "إخفاء" : "إظهار"}</button></div></div>
      <button className="button button-gold button-block" type="submit" disabled={busy}>{busy ? "جارٍ التحقق..." : mode === "login" ? "تسجيل الدخول" : "إنشاء الحساب"}</button>
    </form>
    <p className="auth-footnote">نقاط مكافآت على مشترياتك · بياناتك محفوظة بأمان</p>
    <div style={{ display: "flex", justifyContent: "center", marginTop: 14 }}><Link href="/admin/login" className="admin-hint">دخول إدارة المتجر</Link></div>
  </section></div>;
}

function statusLabel(status: string) { return ({ received: "تم الاستلام", paid: "تم الدفع", processing: "قيد التنفيذ", ready: "جاهز", delivered: "تم التسليم", cancelled: "ملغي" } as Record<string, string>)[status] || status; }
