import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { StoreProvider } from "@/components/StoreProvider";
import { SiteChrome } from "@/components/SiteChrome";

export const metadata: Metadata = {
  title: "VEXORA – عالمك الرقمي",
  description: "شحن ألعاب وبطاقات هدايا ومنتجات رقمية أصلية في مصر.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <StoreProvider><SiteChrome>{children}</SiteChrome></StoreProvider>
      </body>
    </html>
  );
}
