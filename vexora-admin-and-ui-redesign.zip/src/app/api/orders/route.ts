import { and, eq, gt, gte, inArray, isNull, lte, or, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons, customers, exclusiveOffers, orders, packages, products } from "@/db/schema";
import { getSession, normalizePhone } from "@/lib/auth";
import { getSafeStoreSettings, imagePath } from "@/lib/store";

export const dynamic = "force-dynamic";

const paymentMethods = new Set(["vodafone", "instapay", "bank", "whatsapp"]);
const loyaltyRules = { earnEveryEgp: 10, redeemBlock: 100, egpPerBlock: 1, maxShare: 0.5, maxDiscountEgp: 10 };

type RequestedItem = { productId: number; packageIndex: number; quantity: number; playerId?: string };
type RequestedOrder = { customerName?: string; phone?: string; email?: string; paymentMethod?: string; discountCode?: string; usePoints?: boolean; items?: RequestedItem[] };

function numeric(value: string | number | null | undefined) { return Number(value || 0); }
function digits(value: string) { return value.replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit))); }

export async function POST(request: Request) {
  let body: RequestedOrder;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات الطلب غير صالحة." }, { status: 400 }); }
  const customerName = String(body.customerName || "").trim().slice(0, 100);
  const phone = normalizePhone(String(body.phone || ""));
  const email = String(body.email || "").trim().toLowerCase().slice(0, 190) || null;
  const paymentMethod = String(body.paymentMethod || "whatsapp");
  const requestedItems = Array.isArray(body.items) ? body.items : [];
  if (customerName.length < 2 || !/^\+?\d{10,14}$/.test(phone)) return NextResponse.json({ error: "أدخل الاسم ورقم الهاتف بصيغة صحيحة." }, { status: 400 });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "البريد الإلكتروني غير صالح." }, { status: 400 });
  if (!paymentMethods.has(paymentMethod)) return NextResponse.json({ error: "طريقة الدفع غير مدعومة." }, { status: 400 });
  if (requestedItems.length < 1 || requestedItems.length > 50) return NextResponse.json({ error: "السلة فارغة أو تحتوي على عناصر كثيرة جداً." }, { status: 400 });

  const normalizedItems = requestedItems.map((item) => ({
    productId: Number(item?.productId), packageIndex: Number(item?.packageIndex), quantity: Number(item?.quantity), playerId: digits(String(item?.playerId || "").trim()),
  }));
  if (normalizedItems.some((item) => !Number.isInteger(item.productId) || !Number.isInteger(item.packageIndex) || item.packageIndex < 0 || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20)) {
    return NextResponse.json({ error: "تأكد من المنتج والباقة والكمية." }, { status: 400 });
  }
  const requestedProductIds = [...new Set(normalizedItems.map((item) => item.productId))];
  const productRows = await db.select().from(products).where(and(inArray(products.legacyId, requestedProductIds), eq(products.active, true)));
  const productByLegacyId = new Map(productRows.map((item) => [item.legacyId, item]));
  const productDbIds = productRows.map((item) => item.id);
  const packageRows = productDbIds.length ? await db.select().from(packages).where(and(inArray(packages.productId, productDbIds), eq(packages.active, true))) : [];
  const packageBySelection = new Map(packageRows.map((item) => [`${item.productId}:${item.legacyIndex}`, item]));
  const selectedPackages = normalizedItems.map((item) => {
    const product = productByLegacyId.get(item.productId);
    const pack = product ? packageBySelection.get(`${product.id}:${item.packageIndex}`) : undefined;
    return { request: item, product, pack };
  });
  if (selectedPackages.some((entry) => !entry.product || !entry.pack)) return NextResponse.json({ error: "تغيّرت إحدى الباقات في السلة. حدّث الصفحة ثم أعد المحاولة." }, { status: 409 });
  for (const entry of selectedPackages) {
    if (entry.product?.requiresPlayerId && !/^\d{5,14}$/.test(entry.request.playerId)) return NextResponse.json({ error: `أدخل Player ID صحيحاً لمنتج ${entry.product.nameAr} (من 5 إلى 14 رقماً).` }, { status: 400 });
  }

  const packageIds = [...new Set(selectedPackages.map((entry) => entry.pack!.id))];
  const now = new Date();
  const offerRows = packageIds.length ? await db.select().from(exclusiveOffers).where(and(eq(exclusiveOffers.active, true), inArray(exclusiveOffers.packageId, packageIds), lte(exclusiveOffers.startsAt, now), gte(exclusiveOffers.endsAt, now))) : [];
  const offerByPackage = new Map<string, typeof offerRows>();
  for (const offer of offerRows) {
    const values = offerByPackage.get(offer.packageId) || [];
    values.push(offer);
    offerByPackage.set(offer.packageId, values);
  }

  const lineItems = selectedPackages.map(({ request: item, product, pack }) => {
    const currentPrice = numeric(pack!.price);
    const offer = (offerByPackage.get(pack!.id) || []).filter((entry) => numeric(entry.discountPrice) > 0 && numeric(entry.discountPrice) < currentPrice).sort((a, b) => numeric(a.discountPrice) - numeric(b.discountPrice))[0];
    const productImage = imagePath(product!.imageId || product!.defaultImageId, product!.fallbackImageUrl);
    return {
      productId: product!.legacyId,
      packageIndex: pack!.legacyIndex,
      productName: product!.nameAr,
      packageName: pack!.nameAr,
      image: imagePath(pack!.imageId, productImage),
      quantity: item.quantity,
      playerId: item.playerId,
      unitPrice: offer ? numeric(offer.discountPrice) : currentPrice,
      originalPrice: currentPrice,
      ...(offer ? { offerTitle: offer.title } : {}),
      _offerDiscount: (currentPrice - (offer ? numeric(offer.discountPrice) : currentPrice)) * item.quantity,
      _categoryId: product!.categoryId,
    };
  });
  const subtotal = lineItems.reduce((sum, item) => sum + item.originalPrice * item.quantity, 0);
  const offerDiscount = lineItems.reduce((sum, item) => sum + item._offerDiscount, 0);
  const netAfterOffers = Math.max(0, subtotal - offerDiscount);

  const discountCode = String(body.discountCode || "").trim().toUpperCase();
  let coupon: typeof coupons.$inferSelect | null = null;
  let couponDiscount = 0;
  if (discountCode) {
    const [found] = await db.select().from(coupons).where(and(
      eq(coupons.code, discountCode), eq(coupons.active, true),
      or(isNull(coupons.startsAt), lte(coupons.startsAt, now)),
      or(isNull(coupons.endsAt), gt(coupons.endsAt, now)),
    )).limit(1);
    if (!found || (found.maxUses !== null && found.usedCount >= found.maxUses)) return NextResponse.json({ error: "كود الخصم غير صالح أو انتهت صلاحيته." }, { status: 400 });
    const eligibleSubtotal = found.categoryId ? lineItems.reduce((sum, item) => sum + (item._categoryId === found!.categoryId ? item.unitPrice * item.quantity : 0), 0) : netAfterOffers;
    if (eligibleSubtotal < numeric(found.minPurchase)) return NextResponse.json({ error: "قيمة الطلب أقل من الحد الأدنى لاستخدام الكود." }, { status: 400 });
    const rawDiscount = found.type === "fixed" ? numeric(found.value) : eligibleSubtotal * numeric(found.value) / 100;
    couponDiscount = Math.min(eligibleSubtotal, rawDiscount, found.maxDiscount === null ? Number.POSITIVE_INFINITY : numeric(found.maxDiscount));
    coupon = found;
  }
  const netAfterCoupon = Math.max(0, netAfterOffers - couponDiscount);

  let customerId: string | null = null;
  let customerPoints = 0;
  const session = await getSession();
  if (session?.role === "customer") {
    const [customer] = await db.select({ id: customers.id, points: customers.points }).from(customers).where(eq(customers.id, session.sub)).limit(1);
    if (customer) { customerId = customer.id; customerPoints = customer.points; }
  }
  let pointsRedeemed = 0;
  let pointsDiscount = 0;
  if (body.usePoints) {
    if (!customerId) return NextResponse.json({ error: "سجّل الدخول لاستخدام نقاط المكافآت." }, { status: 401 });
    const maxByBalance = Math.floor(customerPoints / loyaltyRules.redeemBlock) * loyaltyRules.redeemBlock;
    const maxByShare = Math.floor(netAfterCoupon * loyaltyRules.maxShare / loyaltyRules.egpPerBlock) * loyaltyRules.redeemBlock;
    const maxByLimit = Math.floor(loyaltyRules.maxDiscountEgp / loyaltyRules.egpPerBlock) * loyaltyRules.redeemBlock;
    pointsRedeemed = Math.max(0, Math.min(maxByBalance, maxByShare, maxByLimit));
    pointsDiscount = pointsRedeemed / loyaltyRules.redeemBlock * loyaltyRules.egpPerBlock;
  }
  const total = Math.max(0, netAfterCoupon - pointsDiscount);
  const pointsEarned = Math.floor(total / loyaltyRules.earnEveryEgp);
  const cleanItems = lineItems.map(({ _offerDiscount: _discard, _categoryId: _category, ...item }) => item);
  const number = `VX-${new Date().getFullYear()}-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString("hex").toUpperCase()}`;
  const message = [
    `طلب جديد من VEXORA · ${number}`,
    `الاسم: ${customerName}`,
    `الهاتف: ${phone}`,
    ...cleanItems.map((item) => `• ${item.productName} — ${item.packageName} × ${item.quantity}${item.playerId ? ` · ID ${item.playerId}` : ""} = ${(item.unitPrice * item.quantity).toFixed(2)} ج.م`),
    `الإجمالي: ${total.toFixed(2)} ج.م`,
    `طريقة الدفع: ${paymentMethod}`,
  ].join("\n");
  const store = await getSafeStoreSettings();
  const whatsappNumber = (process.env.WHATSAPP_NUMBER || store.whatsappNumber).replace(/\D/g, "");
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

  try {
    const created = await db.transaction(async (tx) => {
      if (coupon) {
        const result = await tx.update(coupons).set({ usedCount: sql`${coupons.usedCount} + 1` }).where(and(
          eq(coupons.id, coupon!.id), eq(coupons.active, true),
          or(isNull(coupons.maxUses), gt(coupons.maxUses, coupons.usedCount)),
        )).returning({ id: coupons.id });
        if (!result.length) throw new Error("تعذر استخدام الكود. ربما انتهت صلاحيته.");
      }
      if (pointsRedeemed && customerId) {
        const updated = await tx.update(customers).set({ points: sql`${customers.points} - ${pointsRedeemed}` }).where(and(eq(customers.id, customerId), gte(customers.points, pointsRedeemed))).returning({ id: customers.id });
        if (!updated.length) throw new Error("رصيد النقاط غير كافٍ. حدّث الصفحة وحاول مرة أخرى.");
      }
      const [order] = await tx.insert(orders).values({
        number, customerId, customerName, phone, email, paymentMethod, status: "received", items: cleanItems,
        subtotal: subtotal.toFixed(2), offerDiscount: offerDiscount.toFixed(2), couponDiscount: couponDiscount.toFixed(2),
        pointsDiscount: pointsDiscount.toFixed(2), pointsRedeemed, total: total.toFixed(2), pointsEarned,
        timeline: [{ status: "received", at: new Date().toISOString() }],
      }).returning({ id: orders.id, number: orders.number, createdAt: orders.createdAt });
      return order;
    });
    return NextResponse.json({ ...created, phone, total, subtotal, discount: offerDiscount + couponDiscount + pointsDiscount, offerDiscount, couponDiscount, pointsDiscount, pointsEarned, items: cleanItems, message, whatsappUrl }, { status: 201 });
  } catch (error) {
    const messageText = error instanceof Error ? error.message : "تعذر حفظ الطلب.";
    if (messageText.includes("تعذر استخدام الكود") || messageText.includes("رصيد النقاط")) return NextResponse.json({ error: messageText }, { status: 409 });
    console.error("Order creation failed", error);
    return NextResponse.json({ error: "تعذر تسجيل الطلب الآن. حاول مرة أخرى." }, { status: 500 });
  }
}
