import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { normalizePhone } from "@/lib/auth";

export async function POST(request: Request) {
  let body: { number?: string; phone?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "أدخل رقم الطلب ورقم الهاتف." }, { status: 400 }); }
  const number = String(body.number || "").trim().toUpperCase();
  const phone = normalizePhone(String(body.phone || ""));
  if (!number || !phone) return NextResponse.json({ error: "أدخل رقم الطلب ورقم الهاتف." }, { status: 400 });
  const [order] = await db.select({ number: orders.number, customerName: orders.customerName, phone: orders.phone, status: orders.status, total: orders.total, items: orders.items, timeline: orders.timeline, createdAt: orders.createdAt }).from(orders).where(and(eq(orders.number, number), eq(orders.phone, phone))).limit(1);
  if (!order) return NextResponse.json({ error: "لم نعثر على طلب بهذه البيانات." }, { status: 404 });
  return NextResponse.json({ ...order, total: Number(order.total), status: order.status });
}
