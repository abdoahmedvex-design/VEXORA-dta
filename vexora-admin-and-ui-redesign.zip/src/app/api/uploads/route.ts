import { NextResponse } from "next/server";
import { db } from "@/db";
import { mediaAssets } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const MAX_BYTES = 5 * 1024 * 1024;

function detectImage(bytes: Uint8Array) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return "image/png";
  if (bytes.length >= 12 && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return "image/webp";
  return null;
}

export async function POST(request: Request) {
  const session = await getSession();
  if (session?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "اختر صورة أولاً." }, { status: 400 });
    if (file.size < 1 || file.size > MAX_BYTES) return NextResponse.json({ error: "حجم الصورة يجب ألا يتجاوز 5 ميغابايت." }, { status: 413 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    const mimeType = detectImage(bytes);
    if (!mimeType || !["image/jpeg", "image/png", "image/webp"].includes(file.type)) return NextResponse.json({ error: "الصيغ المدعومة فقط JPG وPNG وWEBP." }, { status: 415 });
    const [asset] = await db.insert(mediaAssets).values({
      mimeType,
      dataBase64: Buffer.from(bytes).toString("base64"),
      fileName: file.name.replace(/[\\/\0]/g, "").slice(0, 120) || "image",
      size: bytes.byteLength,
    }).returning({ id: mediaAssets.id });
    return NextResponse.json({ id: asset.id, url: `/api/images/${asset.id}` });
  } catch (error) {
    console.error("Image upload failed", error);
    return NextResponse.json({ error: "تعذر حفظ الصورة. حاول مجدداً." }, { status: 500 });
  }
}
