import { and, eq, gt, isNull, lte, or } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";

export async function POST(request: Request) {
  let body: { code?: string; subtotal?: number };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات القسيمة غير صالحة." }, { status: 400 }); }
  const code = String(body.code || "").trim().toUpperCase();
  if (!code || code.length > 50) return NextResponse.json({ error: "أدخل كود خصم صحيحاً." }, { status: 400 });
  const now = new Date();
  const [coupon] = await db.select().from(coupons).where(and(
    eq(coupons.code, code), eq(coupons.active, true),
    or(isNull(coupons.startsAt), lte(coupons.startsAt, now)),
    or(isNull(coupons.endsAt), gt(coupons.endsAt, now)),
  )).limit(1);
  if (!coupon || (coupon.maxUses !== null && coupon.usedCount >= coupon.maxUses)) return NextResponse.json({ error: "كود الخصم غير صالح أو انتهت صلاحيته." }, { status: 404 });
  if (Number(body.subtotal || 0) < Number(coupon.minPurchase)) return NextResponse.json({ error: `الحد الأدنى لاستخدام الكود هو ${Number(coupon.minPurchase)} ج.م.` }, { status: 400 });
  return NextResponse.json({ code: coupon.code, type: coupon.type, value: Number(coupon.value), maxDiscount: coupon.maxDiscount ? Number(coupon.maxDiscount) : null, categoryId: coupon.categoryId });
}
