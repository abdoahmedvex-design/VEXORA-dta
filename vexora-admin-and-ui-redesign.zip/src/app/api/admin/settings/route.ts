import { NextResponse } from "next/server";
import { db } from "@/db";
import { storeSettings } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { getSafeStoreSettings } from "@/lib/store";

export async function GET() {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  return NextResponse.json(await getSafeStoreSettings());
}

export async function PATCH(request: Request) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const body = await request.json();
    const tagline = String(body.tagline || "").trim().slice(0, 200);
    const whatsappNumber = String(body.whatsappNumber || "").trim();
    const paymentDetails = String(body.paymentDetails || "").trim().slice(0, 2000);
    if (whatsappNumber && !/^\+?[\d\s()-]{8,24}$/.test(whatsappNumber)) return NextResponse.json({ error: "رقم واتساب غير صالح." }, { status: 400 });
    await db.insert(storeSettings).values({ id: "store", tagline: tagline || "عالمك الرقمي بمستوى أرقى", whatsappNumber, paymentDetails })
      .onConflictDoUpdate({ target: storeSettings.id, set: { tagline: tagline || "عالمك الرقمي بمستوى أرقى", whatsappNumber, paymentDetails, updatedAt: new Date() } });
    return NextResponse.json({ success: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر حفظ الإعدادات." }, { status: 400 }); }
}
