import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { exclusiveOffers, packages, products } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { getAdminOffers } from "@/lib/store";
import { toDecimal } from "@/lib/money";

export const dynamic = "force-dynamic";

function parseDate(value: unknown) {
  const date = new Date(String(value || ""));
  if (!Number.isFinite(date.getTime())) throw new Error("تاريخ العرض غير صالح.");
  return date;
}

export async function GET() {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try { return NextResponse.json({ offers: await getAdminOffers() }); }
  catch (error) { console.error("Admin offers query failed", error); return NextResponse.json({ error: "تعذر تحميل العروض." }, { status: 500 }); }
}

export async function POST(request: Request) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const body = await request.json();
    const productId = String(body.productId || "");
    const packageId = String(body.packageId || "");
    const title = String(body.title || "").trim().slice(0, 160);
    const startsAt = parseDate(body.startsAt);
    const endsAt = parseDate(body.endsAt);
    const discountPrice = toDecimal(body.discountPrice, "السعر بعد الخصم");
    if (!/^[0-9a-f-]{36}$/i.test(productId) || !/^[0-9a-f-]{36}$/i.test(packageId) || !title || endsAt <= startsAt) return NextResponse.json({ error: "تحقق من اسم العرض والباقات والتواريخ." }, { status: 400 });
    const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
    const [pack] = await db.select().from(packages).where(and(eq(packages.id, packageId), eq(packages.productId, productId))).limit(1);
    if (!product || !pack) return NextResponse.json({ error: "المنتج أو الباقة غير موجودين." }, { status: 404 });
    if (Number(discountPrice) <= 0 || Number(discountPrice) >= Number(pack.price)) return NextResponse.json({ error: "سعر العرض يجب أن يكون أقل من السعر الحالي للباقة وأكبر من صفر." }, { status: 400 });
    const active = body.active !== false;
    if (active) {
      const existing = await db.select().from(exclusiveOffers).where(and(eq(exclusiveOffers.packageId, packageId), eq(exclusiveOffers.active, true)));
      if (existing.some((item) => startsAt < item.endsAt && endsAt > item.startsAt)) return NextResponse.json({ error: "يوجد عرض آخر متداخل زمنياً لهذه الباقة. أوقفه أو غيّر مدته أولاً." }, { status: 409 });
    }
    const imageId = body.imageId && /^[0-9a-f-]{36}$/i.test(String(body.imageId)) ? String(body.imageId) : null;
    const [offer] = await db.insert(exclusiveOffers).values({
      title, description: String(body.description || "").trim().slice(0, 1000), productId, packageId, imageId,
      discountPrice, startsAt, endsAt, active, sortOrder: Number.isInteger(body.sortOrder) ? body.sortOrder : 0,
    }).returning();
    return NextResponse.json({ offer }, { status: 201 });
  } catch (error) {
    console.error("Offer create failed", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر إنشاء العرض." }, { status: 400 });
  }
}
