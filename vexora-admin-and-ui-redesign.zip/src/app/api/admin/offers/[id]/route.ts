import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { exclusiveOffers, packages } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { toDecimal } from "@/lib/money";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "العرض غير موجود." }, { status: 404 });
  try {
    const body = await request.json();
    const [old] = await db.select().from(exclusiveOffers).where(eq(exclusiveOffers.id, id)).limit(1);
    if (!old) return NextResponse.json({ error: "العرض غير موجود." }, { status: 404 });
    const productId = String(body.productId ?? old.productId);
    const packageId = String(body.packageId ?? old.packageId);
    const [pack] = await db.select().from(packages).where(and(eq(packages.id, packageId), eq(packages.productId, productId))).limit(1);
    if (!pack) return NextResponse.json({ error: "المنتج أو الباقة غير موجودين." }, { status: 404 });
    const discountPrice = "discountPrice" in body ? toDecimal(body.discountPrice, "السعر بعد الخصم") : Number(old.discountPrice).toFixed(2);
    if (Number(discountPrice) <= 0 || Number(discountPrice) >= Number(pack.price)) return NextResponse.json({ error: "سعر العرض يجب أن يكون أقل من السعر الحالي للباقة." }, { status: 400 });
    const startsAt = "startsAt" in body ? new Date(String(body.startsAt)) : old.startsAt;
    const endsAt = "endsAt" in body ? new Date(String(body.endsAt)) : old.endsAt;
    if (!Number.isFinite(startsAt.getTime()) || !Number.isFinite(endsAt.getTime()) || endsAt <= startsAt) return NextResponse.json({ error: "تاريخ العرض غير صالح." }, { status: 400 });
    const active = "active" in body ? Boolean(body.active) : old.active;
    if (active) {
      const overlapping = await db.select().from(exclusiveOffers).where(and(eq(exclusiveOffers.packageId, packageId), eq(exclusiveOffers.active, true)));
      if (overlapping.some((offer) => offer.id !== id && startsAt < offer.endsAt && endsAt > offer.startsAt)) return NextResponse.json({ error: "يوجد عرض آخر متداخل زمنياً لهذه الباقة." }, { status: 409 });
    }
    const imageId = "imageId" in body ? (body.imageId && /^[0-9a-f-]{36}$/i.test(String(body.imageId)) ? String(body.imageId) : null) : old.imageId;
    await db.update(exclusiveOffers).set({
      title: String(body.title ?? old.title).trim().slice(0, 160), description: String(body.description ?? old.description).trim().slice(0, 1000),
      productId, packageId, imageId, discountPrice, startsAt, endsAt, active,
      sortOrder: Number.isInteger(body.sortOrder) ? body.sortOrder : old.sortOrder, updatedAt: new Date(),
    }).where(eq(exclusiveOffers.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Offer update failed", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر تعديل العرض." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "العرض غير موجود." }, { status: 404 });
  await db.delete(exclusiveOffers).where(eq(exclusiveOffers.id, id));
  return NextResponse.json({ success: true });
}
