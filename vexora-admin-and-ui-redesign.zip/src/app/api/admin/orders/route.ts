import { and, desc, eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders, type OrderTimelineEntry } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";
const statuses = new Set(["received", "paid", "processing", "ready", "delivered", "cancelled"]);

export async function GET() {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const result = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(100);
  return NextResponse.json({ orders: result.map((order) => ({ ...order, subtotal: Number(order.subtotal), offerDiscount: Number(order.offerDiscount), couponDiscount: Number(order.couponDiscount), pointsDiscount: Number(order.pointsDiscount), total: Number(order.total) })) });
}

export async function PATCH(request: Request) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  let body: { id?: string; status?: string; note?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const id = String(body.id || "");
  const status = String(body.status || "");
  if (!/^[0-9a-f-]{36}$/i.test(id) || !statuses.has(status)) return NextResponse.json({ error: "حالة الطلب غير صالحة." }, { status: 400 });
  try {
    await db.transaction(async (tx) => {
      const [order] = await tx.select().from(orders).where(eq(orders.id, id)).limit(1);
      if (!order) throw new Error("الطلب غير موجود.");
      const now = new Date();
      const history: OrderTimelineEntry[] = Array.isArray(order.timeline) ? order.timeline : [];
      history.push({ status, at: now.toISOString(), note: String(body.note || "").trim().slice(0, 300) || undefined });
      if (status === "delivered" && order.customerId && !order.pointsAwardedAt && order.pointsEarned > 0) {
        await tx.update(customers).set({ points: sql`${customers.points} + ${order.pointsEarned}` }).where(eq(customers.id, order.customerId));
      }
      if (status === "cancelled" && order.customerId && !order.pointsRestoredAt && order.pointsRedeemed > 0) {
        await tx.update(customers).set({ points: sql`${customers.points} + ${order.pointsRedeemed}` }).where(eq(customers.id, order.customerId));
      }
      await tx.update(orders).set({
        status, timeline: history, updatedAt: now,
        ...(status === "delivered" && !order.pointsAwardedAt ? { pointsAwardedAt: now } : {}),
        ...(status === "cancelled" && !order.pointsRestoredAt ? { pointsRestoredAt: now } : {}),
      }).where(and(eq(orders.id, id)));
    });
    return NextResponse.json({ success: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر تحديث الطلب." }, { status: 400 }); }
}
