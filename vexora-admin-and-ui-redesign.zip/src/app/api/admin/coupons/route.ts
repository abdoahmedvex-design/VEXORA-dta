import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { toDecimal } from "@/lib/money";

export const dynamic = "force-dynamic";

function parseOptionalDate(value: unknown) {
  if (value === null || value === undefined || value === "") return null;
  const date = new Date(String(value));
  if (!Number.isFinite(date.getTime())) throw new Error("تاريخ الكوبون غير صالح.");
  return date;
}

function couponValues(body: Record<string, unknown>) {
  const code = String(body.code || "").trim().toUpperCase();
  const type = String(body.type || "percent");
  const value = toDecimal(body.value, "قيمة الخصم");
  const minPurchase = toDecimal(body.minPurchase ?? 0, "الحد الأدنى");
  const maxDiscount = body.maxDiscount === null || body.maxDiscount === "" || body.maxDiscount === undefined ? null : toDecimal(body.maxDiscount, "الخصم الأقصى");
  const startsAt = parseOptionalDate(body.startsAt);
  const endsAt = parseOptionalDate(body.endsAt);
  const maxUses = body.maxUses === null || body.maxUses === "" || body.maxUses === undefined ? null : Number(body.maxUses);
  if (!/^[A-Z0-9_-]{3,50}$/.test(code) || !["percent", "fixed"].includes(type) || Number(value) <= 0 || (type === "percent" && Number(value) > 100) || Number(minPurchase) < 0 || (maxUses !== null && (!Number.isInteger(maxUses) || maxUses < 1)) || (startsAt && endsAt && endsAt <= startsAt)) throw new Error("تحقق من الكود وقيمة الخصم وتواريخ الصلاحية.");
  return { code, type, value, minPurchase, maxDiscount, startsAt, endsAt, maxUses, active: body.active !== false, categoryId: body.categoryId ? String(body.categoryId) : null };
}

export async function GET() {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const rows = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
  return NextResponse.json({ coupons: rows.map((item) => ({ ...item, value: Number(item.value), minPurchase: Number(item.minPurchase), maxDiscount: item.maxDiscount ? Number(item.maxDiscount) : null })) });
}

export async function POST(request: Request) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const body = await request.json();
    const [coupon] = await db.insert(coupons).values(couponValues(body)).returning();
    return NextResponse.json({ coupon }, { status: 201 });
  } catch (error) {
    if (typeof error === "object" && error && "code" in error && error.code === "23505") return NextResponse.json({ error: "كود الخصم مستخدم بالفعل." }, { status: 409 });
    return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر إضافة الكوبون." }, { status: 400 });
  }
}
