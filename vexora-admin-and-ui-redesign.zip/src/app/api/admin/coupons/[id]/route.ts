import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { toDecimal } from "@/lib/money";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "الكوبون غير موجود." }, { status: 404 });
  try {
    const body = await request.json();
    const [old] = await db.select().from(coupons).where(eq(coupons.id, id)).limit(1);
    if (!old) return NextResponse.json({ error: "الكوبون غير موجود." }, { status: 404 });
    const type = String(body.type ?? old.type);
    const value = "value" in body ? toDecimal(body.value, "قيمة الخصم") : Number(old.value).toFixed(2);
    if (!["percent", "fixed"].includes(type) || Number(value) <= 0 || (type === "percent" && Number(value) > 100)) return NextResponse.json({ error: "قيمة الخصم غير صالحة." }, { status: 400 });
    const date = (name: string, previous: Date | null) => {
      if (!(name in body)) return previous;
      if (!body[name]) return null;
      const parsed = new Date(String(body[name]));
      if (!Number.isFinite(parsed.getTime())) throw new Error("تاريخ الكوبون غير صالح.");
      return parsed;
    };
    const startsAt = date("startsAt", old.startsAt);
    const endsAt = date("endsAt", old.endsAt);
    if (startsAt && endsAt && endsAt <= startsAt) return NextResponse.json({ error: "نهاية الصلاحية يجب أن تكون بعد البداية." }, { status: 400 });
    const maxDiscount = "maxDiscount" in body ? (body.maxDiscount === null || body.maxDiscount === "" ? null : toDecimal(body.maxDiscount, "الخصم الأقصى")) : old.maxDiscount;
    const maxUses = "maxUses" in body ? (body.maxUses === null || body.maxUses === "" ? null : Number(body.maxUses)) : old.maxUses;
    const code = String(body.code ?? old.code).trim().toUpperCase();
    if (!/^[A-Z0-9_-]{3,50}$/.test(code) || (maxUses !== null && (!Number.isInteger(maxUses) || maxUses < 1))) return NextResponse.json({ error: "الكود أو الحد الأقصى للاستخدام غير صالح." }, { status: 400 });
    await db.update(coupons).set({
      code, type, value, minPurchase: "minPurchase" in body ? toDecimal(body.minPurchase, "الحد الأدنى") : old.minPurchase,
      maxDiscount, maxUses, active: "active" in body ? Boolean(body.active) : old.active,
      categoryId: "categoryId" in body ? (body.categoryId ? String(body.categoryId) : null) : old.categoryId,
      startsAt, endsAt,
    }).where(eq(coupons.id, id));
    return NextResponse.json({ success: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر تعديل الكوبون." }, { status: 400 }); }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "الكوبون غير موجود." }, { status: 404 });
  await db.delete(coupons).where(eq(coupons.id, id));
  return NextResponse.json({ success: true });
}
