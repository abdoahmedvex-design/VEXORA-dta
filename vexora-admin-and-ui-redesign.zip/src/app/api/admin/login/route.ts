import { createHash, timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { issueSession } from "@/lib/auth";

function sameSecret(left: string, right: string) {
  return timingSafeEqual(createHash("sha256").update(left).digest(), createHash("sha256").update(right).digest());
}

export async function POST(request: Request) {
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminEmail || !adminPassword) return NextResponse.json({ error: "بيانات الأدمن غير مهيأة. أضف ADMIN_EMAIL وADMIN_PASSWORD إلى متغيرات البيئة أولاً." }, { status: 503 });
  let body: { email?: string; password?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  if (!sameSecret(email, adminEmail) || !sameSecret(password, adminPassword)) return NextResponse.json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة." }, { status: 401 });
  await issueSession({ role: "admin", sub: "vexora-admin", email });
  return NextResponse.json({ success: true });
}
