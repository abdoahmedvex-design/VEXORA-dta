import { and, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { exclusiveOffers, packages, products } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { toDecimal } from "@/lib/money";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "المنتج غير موجود." }, { status: 404 });
  try {
    const body = await request.json();
    const [existing] = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (!existing) return NextResponse.json({ error: "المنتج غير موجود." }, { status: 404 });
    const productPatch: Partial<typeof products.$inferInsert> = { updatedAt: new Date() };
    for (const field of ["nameAr", "nameEn", "descriptionAr", "descriptionEn", "deliveryAr", "deliveryEn", "categoryId"] as const) {
      if (field in body) productPatch[field] = String(body[field] ?? "").trim().slice(0, field.startsWith("description") ? 2000 : 200);
    }
    if ("requiresPlayerId" in body) productPatch.requiresPlayerId = Boolean(body.requiresPlayerId);
    if ("active" in body) productPatch.active = Boolean(body.active);
    if ("sortOrder" in body && Number.isInteger(body.sortOrder)) productPatch.sortOrder = body.sortOrder;
    if ("imageId" in body) {
      if (body.imageId === null || body.imageId === "") productPatch.imageId = null;
      else if (typeof body.imageId === "string" && /^[0-9a-f-]{36}$/i.test(body.imageId)) productPatch.imageId = body.imageId;
      else throw new Error("معرّف صورة المنتج غير صالح.");
    }
    await db.transaction(async (tx) => {
      await tx.update(products).set(productPatch).where(eq(products.id, id));
      if (Array.isArray(body.packages)) {
        const oldPackages = await tx.select().from(packages).where(eq(packages.productId, id));
        const submittedIds = new Set(body.packages.map((item: { id?: string }) => item.id).filter((value: unknown): value is string => typeof value === "string"));
        const removed = oldPackages.filter((item) => !submittedIds.has(item.id)).map((item) => item.id);
        if (removed.length) await tx.delete(packages).where(inArray(packages.id, removed));
        let nextIndex = oldPackages.reduce((maxIndex, item) => Math.max(maxIndex, item.legacyIndex), -1) + 1;
        for (const [sortOrder, item] of body.packages.entries()) {
          const nameAr = String(item?.nameAr || "").trim().slice(0, 160);
          if (!nameAr) throw new Error("اسم كل باقة مطلوب.");
          const packageData = {
            nameAr, nameEn: String(item?.nameEn || "").trim().slice(0, 160), price: toDecimal(item?.price),
            imageId: item?.imageId === null || item?.imageId === "" ? null : typeof item?.imageId === "string" && /^[0-9a-f-]{36}$/i.test(item.imageId) ? item.imageId : null,
            active: item?.active !== false, sortOrder,
          };
          const found = oldPackages.find((old) => old.id === item?.id);
          if (found) await tx.update(packages).set(packageData).where(and(eq(packages.id, found.id), eq(packages.productId, id)));
          else await tx.insert(packages).values({ productId: id, legacyIndex: nextIndex++, ...packageData });
        }
        const remaining = await tx.select().from(packages).where(eq(packages.productId, id));
        if (remaining.length) {
          const offerRows = await tx.select({ id: exclusiveOffers.id, packageId: exclusiveOffers.packageId, discountPrice: exclusiveOffers.discountPrice }).from(exclusiveOffers).where(inArray(exclusiveOffers.packageId, remaining.map((item) => item.id)));
          for (const offer of offerRows) {
            const pack = remaining.find((item) => item.id === offer.packageId);
            if (pack && Number(offer.discountPrice) >= Number(pack.price)) throw new Error("سعر إحدى العروض لم يعد أقل من سعر الباقة. عدّل العرض أو أوقفه أولاً.");
          }
        }
      }
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Admin product update failed", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "تعذر حفظ المنتج." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const { id } = await context.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "المنتج غير موجود." }, { status: 404 });
  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ success: true });
}
