import { asc, eq, max } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, packages, products } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { getAdminProducts } from "@/lib/store";
import { toDecimal } from "@/lib/money";

export const dynamic = "force-dynamic";

function safeImageId(value: unknown) {
  if (value === null || value === "") return null;
  if (typeof value !== "string" || !/^[0-9a-f-]{36}$/i.test(value)) throw new Error("معرّف الصورة غير صالح.");
  return value;
}

export async function GET() {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const [productRows, categoryRows] = await Promise.all([getAdminProducts(), db.select().from(categories).orderBy(asc(categories.sortOrder))]);
    return NextResponse.json({ products: productRows, categories: categoryRows.map((item) => ({ id: item.id, icon: item.icon, nameAr: item.nameAr, nameEn: item.nameEn })) });
  }
  catch (error) { console.error("Admin products query failed", error); return NextResponse.json({ error: "تعذر تحميل المنتجات." }, { status: 500 }); }
}

export async function POST(request: Request) {
  if ((await getSession())?.role !== "admin") return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  try {
    const body = await request.json();
    const nameAr = String(body.nameAr || "").trim().slice(0, 160);
    const nameEn = String(body.nameEn || "").trim().slice(0, 160);
    const categoryId = String(body.categoryId || "").trim();
    const packagesInput = Array.isArray(body.packages) ? body.packages : [];
    if (nameAr.length < 2 || !categoryId || packagesInput.length < 1) return NextResponse.json({ error: "أدخل اسم المنتج والتصنيف وباقة واحدة على الأقل." }, { status: 400 });
    const [category] = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, categoryId)).limit(1);
    if (!category) return NextResponse.json({ error: "التصنيف غير موجود." }, { status: 400 });
    const [row] = await db.select({ value: max(products.legacyId) }).from(products);
    const legacyId = Math.max(10000, Number(row?.value || 0) + 1);
    const imageId = safeImageId(body.imageId);
    const created = await db.transaction(async (tx) => {
      const [product] = await tx.insert(products).values({
        legacyId, categoryId, nameAr, nameEn,
        descriptionAr: String(body.descriptionAr || "").trim().slice(0, 2000),
        descriptionEn: String(body.descriptionEn || "").trim().slice(0, 2000),
        deliveryAr: String(body.deliveryAr || "تسليم سريع").trim().slice(0, 200),
        deliveryEn: String(body.deliveryEn || "Fast delivery").trim().slice(0, 200),
        requiresPlayerId: Boolean(body.requiresPlayerId), imageId, active: body.active !== false,
        sortOrder: Number.isInteger(body.sortOrder) ? body.sortOrder : 0,
      }).returning();
      for (const [index, item] of packagesInput.entries()) {
        const packageNameAr = String(item?.nameAr || "").trim().slice(0, 160);
        if (!packageNameAr) throw new Error("اسم كل باقة مطلوب.");
        await tx.insert(packages).values({
          productId: product.id, legacyIndex: index, nameAr: packageNameAr,
          nameEn: String(item?.nameEn || "").trim().slice(0, 160), price: toDecimal(item?.price),
          imageId: safeImageId(item?.imageId), active: item?.active !== false, sortOrder: index,
        });
      }
      return product;
    });
    return NextResponse.json({ product: created }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر إضافة المنتج.";
    console.error("Admin product create failed", error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
