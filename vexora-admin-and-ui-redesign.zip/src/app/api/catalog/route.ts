import { NextResponse } from "next/server";
import { getCatalog } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json(await getCatalog(), { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Catalog query failed", error);
    return NextResponse.json({ error: "تعذر تحميل كتالوج المتجر." }, { status: 500 });
  }
}
