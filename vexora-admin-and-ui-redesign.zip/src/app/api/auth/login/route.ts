import { or, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { issueSession, normalizePhone, verifyPassword } from "@/lib/auth";

export async function POST(request: Request) {
  let body: { identifier?: string; password?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات الدخول غير صالحة." }, { status: 400 }); }
  const identifier = String(body.identifier || "").trim();
  const password = String(body.password || "");
  if (!identifier || !password) return NextResponse.json({ error: "أدخل رقم الهاتف أو البريد وكلمة المرور." }, { status: 400 });
  const phone = normalizePhone(identifier);
  const email = identifier.toLowerCase();
  const [customer] = await db.select().from(customers).where(or(eq(customers.phone, phone), eq(customers.email, email))).limit(1);
  if (!customer || !(await verifyPassword(password, customer.passwordHash))) return NextResponse.json({ error: "بيانات الدخول غير صحيحة." }, { status: 401 });
  await issueSession({ role: "customer", sub: customer.id, name: customer.name, email: customer.email || undefined });
  return NextResponse.json({ customer: { id: customer.id, name: customer.name, phone: customer.phone, email: customer.email, points: customer.points } });
}
