import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { hashPassword, issueSession, normalizePhone } from "@/lib/auth";

export async function POST(request: Request) {
  let body: { name?: string; phone?: string; email?: string; password?: string };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "بيانات التسجيل غير صالحة." }, { status: 400 }); }
  const name = String(body.name || "").trim().slice(0, 100);
  const phone = normalizePhone(String(body.phone || ""));
  const email = String(body.email || "").trim().toLowerCase().slice(0, 190) || null;
  const password = String(body.password || "");
  if (name.length < 2 || !/^\+?\d{10,14}$/.test(phone)) return NextResponse.json({ error: "أدخل الاسم ورقم هاتف صحيحاً." }, { status: 400 });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "البريد الإلكتروني غير صالح." }, { status: 400 });
  if (password.length < 8 || password.length > 128) return NextResponse.json({ error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل." }, { status: 400 });
  try {
    const [customer] = await db.insert(customers).values({ name, phone, email, passwordHash: await hashPassword(password) }).returning({ id: customers.id, name: customers.name, phone: customers.phone, email: customers.email, points: customers.points });
    await issueSession({ role: "customer", sub: customer.id, name: customer.name, email: customer.email || undefined });
    return NextResponse.json({ customer }, { status: 201 });
  } catch (error) {
    if (typeof error === "object" && error && "code" in error && error.code === "23505") return NextResponse.json({ error: "رقم الهاتف مسجّل مسبقاً. سجّل الدخول بدلاً من ذلك." }, { status: 409 });
    console.error("Customer registration failed", error);
    return NextResponse.json({ error: "تعذر إنشاء الحساب الآن." }, { status: 500 });
  }
}
