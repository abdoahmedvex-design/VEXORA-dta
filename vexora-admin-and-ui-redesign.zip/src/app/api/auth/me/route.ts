import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

const rules = { earnEveryEgp: 10, redeemBlock: 100, egpPerBlock: 1, maxShare: 0.5, maxDiscountEgp: 10 };

export async function GET() {
  const session = await getSession();
  if (session?.role !== "customer") return NextResponse.json({ loggedIn: false, rules });
  const [customer] = await db.select({ id: customers.id, name: customers.name, phone: customers.phone, email: customers.email, points: customers.points }).from(customers).where(eq(customers.id, session.sub)).limit(1);
  if (!customer) return NextResponse.json({ loggedIn: false, rules });
  return NextResponse.json({ loggedIn: true, customer, rules });
}
