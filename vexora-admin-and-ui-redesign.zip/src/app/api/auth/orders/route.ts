import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getSession();
  if (session?.role !== "customer") return NextResponse.json({ error: "سجّل الدخول أولاً." }, { status: 401 });
  const result = await db.select({ number: orders.number, status: orders.status, total: orders.total, createdAt: orders.createdAt, items: orders.items }).from(orders).where(eq(orders.customerId, session.sub)).orderBy(desc(orders.createdAt)).limit(30);
  return NextResponse.json({ orders: result.map((order) => ({ ...order, total: Number(order.total) })) });
}
