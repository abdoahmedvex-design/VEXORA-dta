import { NextResponse } from "next/server";
import { getSafeStoreSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try { return NextResponse.json(await getSafeStoreSettings(), { headers: { "Cache-Control": "no-store" } }); }
  catch { return NextResponse.json({ tagline: "عالمك الرقمي بمستوى أرقى", whatsappNumber: "", paymentDetails: "" }); }
}
