"use client";

import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import { useStore } from "@/components/StoreProvider";

export function SiteChrome({ children }: { children: ReactNode }) {
  const { cart, toast } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const [whatsapp, setWhatsapp] = useState(process.env.NEXT_PUBLIC_WHATSAPP_NUMBER?.replace(/\D/g, "") || "");
  useEffect(() => {
    let cancelled = false;
    fetch("/api/store-info").then((response) => response.json()).then((data) => { if (!cancelled && data.whatsappNumber) setWhatsapp(String(data.whatsappNumber).replace(/\D/g, "")); }).catch(() => {});
    return () => { cancelled = true; };
  }, []);
  const whatsappHref = whatsapp ? `https://wa.me/${whatsapp}` : "https://wa.me/?text=مرحباً، أحتاج مساعدة من VEXORA";

  return <>
    <header className="site-header">
      <div className="site-header-inner">
        <Link className="brand" href="/" aria-label="VEXORA home" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark">V</span><span className="brand-word">VEXORA<small>YOUR DIGITAL WORLD.</small></span>
        </Link>
        <button className="mobile-menu-toggle" type="button" aria-label="فتح القائمة" aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}><span /><span /><span /></button>
        <nav className={`site-nav ${menuOpen ? "is-open" : ""}`}>
          <Link href="/#store" onClick={() => setMenuOpen(false)}>المتجر</Link>
          <Link href="/#offers" onClick={() => setMenuOpen(false)}>العروض</Link>
          <Link href="/#tracking" onClick={() => setMenuOpen(false)}>تتبّع الطلب</Link>
          <Link href="/account" onClick={() => setMenuOpen(false)}>حسابي</Link>
          <Link className="nav-cart" href="/cart" onClick={() => setMenuOpen(false)}>السلة <span>{count}</span></Link>
        </nav>
      </div>
    </header>
    <main className="site-main">{children}</main>
    <footer className="site-footer">
      <div className="footer-inner">
        <div><Link className="brand footer-brand" href="/"><span className="brand-mark">V</span><span className="brand-word">VEXORA<small>YOUR DIGITAL WORLD.</small></span></Link><p>عالمك الرقمي بمستوى أرقى.</p></div>
        <div className="footer-links"><Link href="/#store">تصفّح المتجر</Link><Link href="/track">تتبّع طلبك</Link><Link href="/admin/login">إدارة المتجر</Link><a href={whatsappHref} target="_blank" rel="noreferrer">تواصل واتساب ↗</a></div>
        <small className="copyright">© {new Date().getFullYear()} VEXORA · YOUR DIGITAL WORLD.</small>
      </div>
    </footer>
    <div className={`toast ${toast ? "toast-visible" : ""}`} role="status" aria-live="polite">{toast}</div>
  </>;
}
