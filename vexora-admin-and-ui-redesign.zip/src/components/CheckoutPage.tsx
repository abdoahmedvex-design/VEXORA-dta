"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import type { PublicProduct } from "@/lib/store";
import { formatMoney } from "@/lib/money";
import { useStore } from "@/components/StoreProvider";

type Coupon = { code: string; type: "percent" | "fixed"; value: number; maxDiscount: number | null; categoryId: string | null };
type Me = { loggedIn: boolean; customer?: { name: string; phone: string; email: string | null; points: number }; rules: { earnEveryEgp: number; redeemBlock: number; egpPerBlock: number; maxShare: number; maxDiscountEgp: number } };

export function CheckoutPage() {
  const { cart, ready, clearCart } = useStore();
  const [products, setProducts] = useState<PublicProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [customer, setCustomer] = useState<Me["customer"]>();
  const [paymentDetails, setPaymentDetails] = useState("");
  const [rules, setRules] = useState<Me["rules"]>({ earnEveryEgp: 10, redeemBlock: 100, egpPerBlock: 1, maxShare: .5, maxDiscountEgp: 10 });
  const [form, setForm] = useState({ customerName: "", phone: "", email: "", paymentMethod: "vodafone" });
  const [codeText, setCodeText] = useState("");
  const [coupon, setCoupon] = useState<Coupon | null>(null);
  const [usePoints, setUsePoints] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState<{ number: string; total: number; whatsappUrl: string; message: string; items: { productName: string; packageName: string; quantity: number; image: string | null; unitPrice: number }[] } | null>(null);

  useEffect(() => {
    Promise.all([
      fetch("/api/catalog").then((response) => response.json()),
      fetch("/api/auth/me").then((response) => response.json()),
      fetch("/api/store-info").then((response) => response.json()),
    ]).then(([catalog, me, storeInfo]: [{ products?: PublicProduct[] }, Me, { paymentDetails?: string }]) => {
      setProducts(catalog.products || []); setRules(me.rules || rules); setPaymentDetails(storeInfo.paymentDetails || "");
      if (me.loggedIn && me.customer) { setCustomer(me.customer); setForm((current) => ({ ...current, customerName: me.customer!.name, phone: me.customer!.phone, email: me.customer!.email || "" })); }
    }).catch(() => setError("تعذر تحميل المنتجات. حدّث الصفحة."))
      .finally(() => setLoading(false));
  // The initial values are intentionally fetched once when checkout opens.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const lines = useMemo(() => cart.flatMap((entry) => {
    const product = products.find((item) => item.id === entry.productId);
    const pack = product?.packages.find((item) => item.legacyIndex === entry.packageIndex);
    return product && pack ? [{ entry, product, pack, finalPrice: pack.offer?.discountPrice ?? pack.price }] : [];
  }), [cart, products]);
  const subtotal = lines.reduce((sum, line) => sum + line.pack.price * line.entry.quantity, 0);
  const offerDiscount = lines.reduce((sum, line) => sum + (line.pack.price - line.finalPrice) * line.entry.quantity, 0);
  const afterOffers = Math.max(0, subtotal - offerDiscount);
  const couponBase = coupon?.categoryId ? lines.reduce((sum, line) => sum + (line.product.category === coupon.categoryId ? line.finalPrice * line.entry.quantity : 0), 0) : afterOffers;
  const couponDiscount = coupon ? Math.min(couponBase, coupon.type === "fixed" ? coupon.value : couponBase * coupon.value / 100, coupon.maxDiscount ?? Number.POSITIVE_INFINITY) : 0;
  const afterCoupon = Math.max(0, afterOffers - couponDiscount);
  const redeemable = customer ? Math.max(0, Math.min(
    Math.floor(customer.points / rules.redeemBlock) * rules.redeemBlock,
    Math.floor(afterCoupon * rules.maxShare / rules.egpPerBlock) * rules.redeemBlock,
    Math.floor(rules.maxDiscountEgp / rules.egpPerBlock) * rules.redeemBlock,
  )) : 0;
  const pointsDiscount = usePoints && redeemable ? redeemable / rules.redeemBlock * rules.egpPerBlock : 0;
  const total = Math.max(0, afterCoupon - pointsDiscount);

  async function applyCoupon() {
    setError(""); setMessage("");
    if (!codeText.trim()) return;
    try {
      const response = await fetch("/api/coupon", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: codeText.trim(), subtotal: afterOffers }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "الكود غير صالح.");
      setCoupon(data); setCodeText(data.code); setMessage("تم تطبيق كود الخصم على الباقات المطابقة.");
    } catch (reason) { setCoupon(null); setError(reason instanceof Error ? reason.message : "تعذر التحقق من الكود."); }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
        ...form, discountCode: coupon?.code || "", usePoints: usePoints && redeemable > 0,
        items: lines.map(({ entry }) => ({ productId: entry.productId, packageIndex: entry.packageIndex, quantity: entry.quantity, playerId: entry.playerId })),
      }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تسجيل الطلب.");
      setOrder(data); clearCart(); setUsePoints(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "حدث خطأ. حاول مرة أخرى."); }
    finally { setBusy(false); }
  }

  if (!ready || loading) return <div className="container page-shell"><div className="no-results">جارٍ تجهيز إتمام الطلب...</div></div>;
  if (order) return <div className="container page-shell"><div className="empty-cart"><div className="empty-cart-mark">✓</div><span className="eyebrow">ORDER RECEIVED</span><h1>تم استلام طلبك</h1><p>رقم الطلب <strong style={{ color: "var(--gold-bright)" }}>{order.number}</strong></p><div className="checkout-items" style={{ maxWidth: 430, margin: "18px auto" }}>{order.items?.map((item, index) => <div key={`${item.productName}-${index}`} className="checkout-item"><span className="checkout-item-info">{item.image ? <img className="checkout-thumb" src={item.image} alt={item.packageName} /> : <span className="checkout-thumb checkout-thumb-empty">✧</span>}<span>{item.productName} · {item.packageName} × {item.quantity}</span></span><strong>{formatMoney(item.unitPrice * item.quantity)}</strong></div>)}</div><p>الإجمالي النهائي: <strong style={{ color: "var(--gold-bright)" }}>{formatMoney(order.total)}</strong></p><p>أرسل تفاصيل الطلب عبر واتساب لتأكيد الدفع ومتابعة التنفيذ.</p><div className="hero-actions" style={{ justifyContent: "center" }}><a className="button button-gold" href={order.whatsappUrl} target="_blank" rel="noreferrer">تأكيد عبر واتساب ↗</a><Link className="button button-quiet" href="/#tracking">تتبّع الطلب</Link></div></div></div>;
  if (!cart.length || !lines.length) return <div className="container page-shell"><div className="empty-cart"><div className="empty-cart-mark">◇</div><h1>سلتك فارغة</h1><p>أضف منتجاً إلى السلة أولاً لمتابعة إتمام الطلب.</p><Link className="button button-gold" href="/#store">تصفّح المتجر</Link></div></div>;

  return <div className="container page-shell">
    <p className="breadcrumb"><Link href="/">الرئيسية</Link> / <Link href="/cart">السلة</Link> / إتمام الطلب</p>
    <div className="section-heading"><div><span className="eyebrow">SECURE CHECKOUT</span><h2>إتمام الطلب</h2><p>أدخل بيانات التواصل واختر طريقة الدفع المناسبة.</p></div></div>
    <div className="checkout-layout">
      <form className="checkout-form-card" onSubmit={submit}>
        {error && <p className="form-error">{error}</p>}{message && <p className="form-success">{message}</p>}
        <h3 style={{ marginTop: 0 }}>بيانات العميل</h3>
        <div className="form-grid"><div className="field"><label className="form-label" htmlFor="customer-name">الاسم الكامل</label><input id="customer-name" className="input" autoComplete="name" required minLength={2} value={form.customerName} onChange={(event) => setForm({ ...form, customerName: event.target.value })} /></div><div className="field"><label className="form-label" htmlFor="customer-phone">رقم الهاتف</label><input id="customer-phone" className="input" autoComplete="tel" inputMode="tel" required value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></div><div className="field"><label className="form-label" htmlFor="customer-email">البريد الإلكتروني (اختياري)</label><input id="customer-email" className="input" type="email" autoComplete="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /></div></div>
        <h3>طريقة الدفع المحلية</h3>
        <div className="payment-options" role="group" aria-label="طريقة الدفع">{[["vodafone", "Vodafone Cash"], ["instapay", "InstaPay"], ["bank", "تحويل بنكي"], ["whatsapp", "التنسيق عبر واتساب"]].map(([value, label]) => <button key={value} type="button" className={`payment-option ${form.paymentMethod === value ? "selected" : ""}`} onClick={() => setForm({ ...form, paymentMethod: value })}>{label}</button>)}</div>
        {paymentDetails ? <div className="detail-note" style={{ marginTop: 10, whiteSpace: "pre-line" }}>{paymentDetails}</div> : <p className="admin-hint" style={{ marginTop: 9 }}>تُرسل تفاصيل الدفع والتأكيد عبر واتساب بعد تسجيل الطلب.</p>}
        <div className="field" style={{ marginTop: 22 }}><label className="form-label" htmlFor="coupon-code">كود الخصم</label><div className="track-form" style={{ gridTemplateColumns: "1fr auto", marginTop: 0 }}><input id="coupon-code" className="input" value={codeText} onChange={(event) => setCodeText(event.target.value.toUpperCase())} placeholder="أدخل الكود" /><button className="button button-outline" type="button" onClick={() => void applyCoupon()}>تطبيق</button></div>{coupon && <button type="button" className="remove-link" style={{ marginTop: 7 }} onClick={() => { setCoupon(null); setCodeText(""); }}>إزالة الكود</button>}</div>
        {customer ? <label className="points-toggle" style={{ display: "flex", gap: 9, alignItems: "flex-start", margin: "14px 0", color: "#c6c1b6", fontSize: 11 }}><input type="checkbox" checked={usePoints && redeemable > 0} disabled={redeemable <= 0} onChange={(event) => setUsePoints(event.target.checked)} /><span>{redeemable > 0 ? `استخدم ${redeemable} نقطة = خصم ${formatMoney(pointsDiscount || redeemable / rules.redeemBlock * rules.egpPerBlock)} (رصيدك ${customer.points})` : `رصيدك ${customer.points} نقطة. كل ${rules.redeemBlock} نقطة = خصم ${formatMoney(rules.egpPerBlock)}`}</span></label> : <p className="admin-hint"><Link href="/account" style={{ color: "var(--gold)" }}>سجّل الدخول</Link> لاستخدام نقاط المكافآت وكسب نقاط على الطلبات.</p>}
        <button className="button button-gold button-block" type="submit" disabled={busy}>{busy ? "جارٍ تسجيل الطلب..." : `تأكيد الطلب · ${formatMoney(total)}`}</button>
      </form>
      <aside className="summary-card"><h2>ملخص السلة</h2><div className="checkout-items">{lines.map(({ entry, product, pack, finalPrice }) => <div key={entry.key} className="checkout-item"><span className="checkout-item-info">{pack.image ? <img className="checkout-thumb" src={pack.image} alt={pack.label.ar} /> : <span className="checkout-thumb checkout-thumb-empty">✧</span>}<span>{product.name.ar} · {pack.label.ar} × {entry.quantity}</span></span><strong>{formatMoney(finalPrice * entry.quantity)}</strong></div>)}</div><div className="summary-row"><span>المجموع الفرعي</span><strong>{formatMoney(subtotal)}</strong></div>{offerDiscount > 0 && <div className="summary-row discount"><span>خصم العروض</span><strong>−{formatMoney(offerDiscount)}</strong></div>}{couponDiscount > 0 && <div className="summary-row discount"><span>كود الخصم</span><strong>−{formatMoney(couponDiscount)}</strong></div>}{pointsDiscount > 0 && <div className="summary-row discount"><span>خصم النقاط</span><strong>−{formatMoney(pointsDiscount)}</strong></div>}<div className="summary-row total"><span>الإجمالي</span><strong>{formatMoney(total)}</strong></div><p className="admin-hint">يتم التحقق من جميع الأسعار والخصومات على الخادم قبل حفظ الطلب.</p></aside>
    </div>
  </div>;
}
