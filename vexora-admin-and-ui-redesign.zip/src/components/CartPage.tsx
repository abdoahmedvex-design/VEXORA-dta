"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { PublicProduct } from "@/lib/store";
import { formatMoney } from "@/lib/money";
import { useStore } from "@/components/StoreProvider";

type CatalogResponse = { products: PublicProduct[] };

export function CartPage() {
  const { cart, ready, setQuantity, removeItem } = useStore();
  const [products, setProducts] = useState<PublicProduct[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { fetch("/api/catalog").then((response) => response.json()).then((data: CatalogResponse) => setProducts(data.products || [])).catch(() => setProducts([])).finally(() => setLoading(false)); }, []);
  const lines = useMemo(() => cart.flatMap((entry) => {
    const product = products.find((item) => item.id === entry.productId);
    const pack = product?.packages.find((item) => item.legacyIndex === entry.packageIndex);
    return product && pack ? [{ entry, product, pack, finalPrice: pack.offer?.discountPrice ?? pack.price }] : [];
  }), [cart, products]);
  const subtotal = lines.reduce((sum, line) => sum + line.pack.price * line.entry.quantity, 0);
  const discount = lines.reduce((sum, line) => sum + (line.pack.price - line.finalPrice) * line.entry.quantity, 0);
  const total = subtotal - discount;

  if (!ready || loading) return <div className="container page-shell"><div className="no-results">جارٍ تحميل سلتك...</div></div>;
  if (cart.length === 0 || lines.length === 0) return <div className="container page-shell"><div className="empty-cart"><div className="empty-cart-mark">◇</div><h1>{cart.length && !lines.length ? "تغيّرت بعض الباقات" : "سلتك فارغة"}</h1><p>{cart.length && !lines.length ? "قد تكون الباقة لم تعد متاحة. احذفها وتصفّح أحدث منتجات المتجر." : "لم تختر أي منتج بعد. اكتشف منتجات رقمية أصلية وعروضاً حصرية."}</p><Link className="button button-gold" href="/#store">العودة إلى المتجر</Link></div></div>;

  return <div className="container page-shell">
    <p className="breadcrumb"><Link href="/">الرئيسية</Link> / سلة المشتريات</p>
    <div className="section-heading"><div><span className="eyebrow">YOUR CART</span><h2>سلة المشتريات</h2><p>راجع الباقات والكميات قبل إتمام طلبك.</p></div><span className="section-count">{lines.reduce((sum, line) => sum + line.entry.quantity, 0)} قطعة</span></div>
    <div className="cart-layout">
      <div className="cart-list">{lines.map(({ entry, product, pack, finalPrice }) => <article key={entry.key} className="cart-card">
        <div className="cart-image">{pack.image ? <img src={pack.image} alt={`${product.name.ar} — ${pack.label.ar}`} /> : <span className="product-image-placeholder">✧</span>}</div>
        <div className="cart-info"><h3>{product.name.ar}</h3><p>{pack.label.ar}{entry.playerId ? ` · ID: ${entry.playerId}` : ""}</p><div className="cart-meta"><strong className="price-current">{formatMoney(finalPrice)}</strong>{pack.offer && <><span className="price-old">{formatMoney(pack.price)}</span><span className="status-badge success">خصم {pack.offer.discountPercent}%</span></>}</div></div>
        <div className="cart-actions"><div className="quantity-stepper"><button type="button" aria-label="تقليل الكمية" onClick={() => setQuantity(entry.key, entry.quantity - 1)}>−</button><strong>{entry.quantity}</strong><button type="button" aria-label="زيادة الكمية" onClick={() => setQuantity(entry.key, entry.quantity + 1)}>+</button></div><button className="remove-link" type="button" onClick={() => removeItem(entry.key)}>حذف</button></div>
      </article>)}</div>
      <aside className="summary-card"><h2>ملخص الطلب</h2><div className="summary-row"><span>المجموع الفرعي</span><strong>{formatMoney(subtotal)}</strong></div>{discount > 0 && <div className="summary-row discount"><span>خصومات العروض</span><strong>−{formatMoney(discount)}</strong></div>}<div className="summary-row total"><span>الإجمالي النهائي</span><strong>{formatMoney(total)}</strong></div><p className="admin-hint">يتم تأكيد الأسعار والخصومات مرة أخرى عند إتمام الطلب.</p><Link className="button button-gold button-block" href="/checkout">إتمام الطلب <span aria-hidden="true">←</span></Link><Link className="button button-quiet button-block" href="/#store">متابعة التسوق</Link></aside>
    </div>
  </div>;
}
