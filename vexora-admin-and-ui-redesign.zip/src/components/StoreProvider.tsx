"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CartEntry = {
  productId: number;
  packageIndex: number;
  quantity: number;
  key: string;
  playerId: string;
};

type StoreContextValue = {
  cart: CartEntry[];
  ready: boolean;
  toast: string;
  addItem: (productId: number, packageIndex: number, playerId?: string, quantity?: number) => void;
  setQuantity: (key: string, quantity: number) => void;
  removeItem: (key: string) => void;
  clearCart: () => void;
  notify: (message: string) => void;
};

const CART_KEY = "vexora_cart";
const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
      if (Array.isArray(saved)) {
        setCart(saved.filter((item): item is CartEntry =>
          Number.isInteger(item?.productId) && Number.isInteger(item?.packageIndex) && item.packageIndex >= 0 &&
          Number.isInteger(item?.quantity) && item.quantity > 0 && typeof item?.key === "string" && typeof item?.playerId === "string",
        ).map((item) => ({ ...item, quantity: Math.min(20, item.quantity) })));
      }
    } catch {
      setCart([]);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, ready]);

  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }, []);

  const addItem = useCallback((productId: number, packageIndex: number, playerId = "", quantity = 1) => {
    const normalizedPlayerId = playerId.trim();
    const key = `${productId}:${packageIndex}:${normalizedPlayerId}`;
    setCart((items) => {
      const found = items.find((item) => item.key === key);
      if (found) return items.map((item) => item.key === key ? { ...item, quantity: Math.min(20, item.quantity + quantity) } : item);
      return [...items, { productId, packageIndex, quantity: Math.min(20, Math.max(1, quantity)), key, playerId: normalizedPlayerId }];
    });
    notify("أُضيفت الباقة إلى سلتك");
  }, [notify]);

  const setQuantity = useCallback((key: string, quantity: number) => {
    setCart((items) => items.map((item) => item.key === key ? { ...item, quantity: Math.max(1, Math.min(20, quantity)) } : item));
  }, []);

  const removeItem = useCallback((key: string) => setCart((items) => items.filter((item) => item.key !== key)), []);
  const clearCart = useCallback(() => setCart([]), []);
  const value = useMemo(() => ({ cart, ready, toast, addItem, setQuantity, removeItem, clearCart, notify }), [cart, ready, toast, addItem, setQuantity, removeItem, clearCart, notify]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const value = useContext(StoreContext);
  if (!value) throw new Error("useStore must be used inside StoreProvider");
  return value;
}
