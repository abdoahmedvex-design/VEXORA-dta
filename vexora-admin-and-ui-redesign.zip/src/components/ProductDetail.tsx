"use client";

import Link from "next/link";
import { useState } from "react";
import type { PublicProduct } from "@/lib/store";
import { formatMoney } from "@/lib/money";
import { useStore } from "@/components/StoreProvider";

export function ProductDetail({ product, initialPackageId }: { product: PublicProduct; initialPackageId?: string }) {
  const initialIndex = Math.max(0, product.packages.findIndex((item) => item.id === initialPackageId));
  const [selectedIndex, setSelectedIndex] = useState(initialIndex);
  const [quantity, setQuantity] = useState(1);
  const [playerId, setPlayerId] = useState("");
  const [error, setError] = useState("");
  const { addItem } = useStore();
  const selected = product.packages[selectedIndex];
  const image = selected?.image || product.image;
  const finalPrice = selected?.offer?.discountPrice ?? selected?.price ?? 0;

  function addToCart() {
    if (!selected) return;
    if (product.requiresPlayerId && !/^\d{5,14}$/.test(playerId.replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit))).trim())) {
      setError("أدخل Player ID صحيحاً من 5 إلى 14 رقماً."); return;
    }
    setError(""); addItem(product.id, selected.legacyIndex, playerId, quantity);
  }

  return <div className="container page-shell">
    <p className="breadcrumb"><Link href="/">الرئيسية</Link> / <Link href="/#store">المتجر</Link> / {product.name.ar}</p>
    <div className="product-detail">
      <div className="detail-image">{image ? <img src={image} alt={selected ? `${product.name.ar} — ${selected.label.ar}` : product.name.ar} /> : <div className="detail-placeholder">✧</div>}</div>
      <div className="detail-copy">
        <span className="eyebrow">VEXORA DIGITAL</span>
        <h1>{product.name.ar}</h1>
        <p>{product.description.ar || "منتج رقمي أصلي مع توصيل سريع وآمن."}</p>
        <div className="detail-note"><span>◷</span><span>التسليم المتوقع: {product.delivery.ar}</span></div>
        <label className="form-label">اختر الباقة المناسبة</label>
        <div className="package-list">
          {product.packages.map((item, index) => <button key={item.id} type="button" aria-pressed={selectedIndex === index} className={`package-choice ${selectedIndex === index ? "selected" : ""}`} onClick={() => { setSelectedIndex(index); setError(""); }}>
            <span>{item.label.ar}{item.offer && <small>عرض حصري −{item.offer.discountPercent}%</small>}</span>
            <strong>{item.offer ? <><small>{formatMoney(item.price)}</small>{formatMoney(item.offer.discountPrice)}</> : formatMoney(item.price)}</strong>
          </button>)}
        </div>
        {product.requiresPlayerId && <div className="field"><label className="form-label" htmlFor="player-id">Player ID</label><input id="player-id" className="input" inputMode="numeric" value={playerId} onChange={(event) => setPlayerId(event.target.value)} placeholder="أدخل رقم اللاعب" /><span className="admin-hint">تأكد من رقم اللاعب قبل إتمام الطلب.</span></div>}
        {error && <p className="form-error">{error}</p>}
        {selected && <div className="detail-buy-row"><div className="quantity-stepper"><button type="button" aria-label="تقليل الكمية" onClick={() => setQuantity((value) => Math.max(1, value - 1))}>−</button><strong>{quantity}</strong><button type="button" aria-label="زيادة الكمية" onClick={() => setQuantity((value) => Math.min(20, value + 1))}>+</button></div><button className="button button-gold" type="button" onClick={addToCart}>أضف إلى السلة · {formatMoney(finalPrice * quantity)}</button></div>}
        <div className="hero-meta" style={{ marginTop: 18 }}><span>دفع محلي آمن</span><span>تأكيد واتساب</span></div>
      </div>
    </div>
  </div>;
}
