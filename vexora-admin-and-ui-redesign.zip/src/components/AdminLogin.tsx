"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تسجيل الدخول.");
      router.replace("/admin"); router.refresh();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر الاتصال. حاول مرة أخرى."); }
    finally { setBusy(false); }
  }

  return <div className="auth-wrap"><section className="auth-card" aria-labelledby="admin-login-heading">
    <div className="auth-brand"><span className="brand-mark">V</span><span className="brand-word">VEXORA<small>YOUR DIGITAL WORLD.</small></span></div>
    <span className="eyebrow">ADMIN ACCESS</span><h1 id="admin-login-heading">إدارة المتجر</h1><p>سجّل الدخول باستخدام بيانات الإدارة المعتمدة.</p>
    {error && <p className="form-error">{error}</p>}
    <form onSubmit={submit}>
      <div className="field"><label className="form-label" htmlFor="admin-email">البريد الإلكتروني</label><input id="admin-email" className="input" type="email" autoComplete="username" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="admin@vexora.store" /></div>
      <div className="field"><label className="form-label" htmlFor="admin-password">كلمة المرور</label><div className="password-wrap"><input id="admin-password" className="input" type={visible ? "text" : "password"} autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} /><button type="button" className="password-toggle" onClick={() => setVisible((value) => !value)}>{visible ? "إخفاء" : "إظهار"}</button></div></div>
      <button className="button button-gold button-block" type="submit" disabled={busy}>{busy ? "جارٍ التحقق..." : "دخول لوحة الإدارة"}</button>
    </form>
    <p className="auth-footnote">تتطلب لوحة الإدارة إعداد ADMIN_EMAIL وADMIN_PASSWORD على الخادم.</p>
    <div style={{ display: "flex", justifyContent: "center", marginTop: 15 }}><Link className="admin-hint" href="/">العودة إلى المتجر</Link></div>
  </section></div>;
}
