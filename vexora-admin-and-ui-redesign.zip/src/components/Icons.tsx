import type { SVGProps } from "react";

type IconName = "spark" | "bag" | "tag" | "cart" | "search" | "check" | "clock" | "shield" | "close" | "plus" | "minus" | "edit" | "trash" | "image" | "box" | "orders" | "settings" | "home";

const paths: Record<IconName, string> = {
  spark: "M12 3l1.5 6.5L20 12l-6.5 1.5L12 20l-1.5-6.5L4 12l6.5-2.5L12 3z",
  bag: "M5 8h14l1 13H4L5 8zm3 0a4 4 0 0 1 8 0",
  tag: "M20 13l-7 7L3 10V4h6l11 9zM7 7h.01",
  cart: "M3 4h2l2.2 11h10.9l2-8H6M9 20h.01M17 20h.01",
  search: "M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm6-2 4 4",
  check: "M5 12l4 4L19 6",
  clock: "M12 8v4l3 2m6-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0z",
  shield: "M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11zm-4-11 3 3 5-5",
  close: "M18 6 6 18M6 6l12 12",
  plus: "M12 5v14m-7-7h14",
  minus: "M5 12h14",
  edit: "M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4L16.5 3.5z",
  trash: "M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m4 4v6m6-6v6",
  image: "M4 5h16v14H4zM8 10h.01M20 15l-5-5L5 19",
  box: "m12 3 9 5-9 5-9-5 9-5zm-9 5v9l9 5 9-5V8m-9 5v9",
  orders: "M4 4h16v16H4zM8 9h8M8 13h8M8 17h5",
  settings: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm0-12v2m0 13v2m8.5-8.5h-2m-13 0h-2m14.5-6-1.4 1.4M5.4 18.6 4 20m16 0-1.4-1.4M5.4 5.4 4 4",
  home: "m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1V10z",
};

export function Icon({ name, size = 18, ...props }: SVGProps<SVGSVGElement> & { name: IconName; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d={paths[name]} /></svg>;
}
