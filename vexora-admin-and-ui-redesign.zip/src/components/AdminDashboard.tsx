"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/StoreProvider";
import { Icon } from "@/components/Icons";
import { formatMoney } from "@/lib/money";

type Category = { id: string; icon: string; nameAr: string; nameEn: string };
type AdminPackage = { id: string; legacyIndex: number; nameAr: string; nameEn: string; price: number; imageId: string | null; active: boolean; sortOrder: number };
type AdminProduct = { id: string; legacyId: number; categoryId: string; nameAr: string; nameEn: string; descriptionAr: string; descriptionEn: string; deliveryAr: string; deliveryEn: string; requiresPlayerId: boolean; imageId: string | null; defaultImageId: string | null; fallbackImageUrl: string | null; active: boolean; sortOrder: number; packages: AdminPackage[]; category?: Category | null };
type PackageDraft = { id?: string; legacyIndex?: number; nameAr: string; nameEn: string; price: string; imageId: string | null; active: boolean };
type ProductDraft = Omit<AdminProduct, "id" | "legacyId" | "category" | "packages"> & { id?: string; legacyId?: number; packages: PackageDraft[] };
type Offer = { id: string; title: string; description: string; productId: string; packageId: string; imageId: string | null; discountPrice: number; startsAt: string; endsAt: string; active: boolean; sortOrder: number; productName: string; packageName: string; basePrice: number };
type OfferDraft = { id?: string; title: string; description: string; productId: string; packageId: string; imageId: string | null; discountPrice: string; startsAt: string; endsAt: string; active: boolean; sortOrder: number };
type Order = { id: string; number: string; customerName: string; phone: string; email: string | null; paymentMethod: string; status: string; items: { productName: string; packageName: string; quantity: number; playerId: string }[]; subtotal: number; offerDiscount: number; couponDiscount: number; pointsDiscount: number; total: number; createdAt: string; timeline: { status: string; at: string; note?: string }[] };
type Coupon = { id: string; code: string; type: string; value: number; minPurchase: number; maxDiscount: number | null; categoryId: string | null; startsAt: string | null; endsAt: string | null; active: boolean; maxUses: number | null; usedCount: number };
type CouponDraft = { id?: string; code: string; type: string; value: string; minPurchase: string; maxDiscount: string; categoryId: string; startsAt: string; endsAt: string; active: boolean; maxUses: string };
type Settings = { tagline: string; whatsappNumber: string; paymentDetails: string };
type Section = "overview" | "products" | "offers" | "orders" | "coupons" | "settings";

const navigation: { id: Section; label: string; icon: "home" | "box" | "tag" | "orders" | "spark" | "settings" }[] = [
  { id: "overview", label: "نظرة عامة", icon: "home" }, { id: "products", label: "المنتجات والباقات", icon: "box" },
  { id: "offers", label: "العروض الحصرية", icon: "tag" }, { id: "orders", label: "الطلبات", icon: "orders" },
  { id: "coupons", label: "أكواد الخصم", icon: "spark" }, { id: "settings", label: "إعدادات المتجر", icon: "settings" },
];
const orderStatuses = ["received", "paid", "processing", "ready", "delivered", "cancelled"];

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "تعذر إتمام العملية.");
  return data as T;
}

function toLocalDateTime(value: string | Date) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "";
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

async function compressImage(file: File) {
  if (file.size > 5 * 1024 * 1024) throw new Error("حجم الصورة يجب ألا يتجاوز 5 ميغابايت.");
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("الصيغ المدعومة JPG وPNG وWEBP.");
  if (typeof createImageBitmap === "undefined") return file;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas"); canvas.width = Math.max(1, Math.round(bitmap.width * scale)); canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) return file;
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", .84));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, ".webp"), { type: "image/webp", lastModified: Date.now() });
  } catch { return file; }
}

export function AdminDashboard() {
  const router = useRouter();
  const { notify } = useStore();
  const [section, setSection] = useState<Section>("overview");
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [settings, setSettings] = useState<Settings>({ tagline: "", whatsappNumber: "", paymentDetails: "" });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [productDraft, setProductDraft] = useState<ProductDraft | null>(null);
  const [offerDraft, setOfferDraft] = useState<OfferDraft | null>(null);
  const [couponDraft, setCouponDraft] = useState<CouponDraft | null>(null);

  const load = useCallback(async () => {
    setError("");
    const [productData, offerData, orderData, couponData, settingsData] = await Promise.all([
      api<{ products: AdminProduct[]; categories: Category[] }>("/api/admin/products"),
      api<{ offers: Offer[] }>("/api/admin/offers"), api<{ orders: Order[] }>("/api/admin/orders"),
      api<{ coupons: Coupon[] }>("/api/admin/coupons"), api<Settings>("/api/admin/settings"),
    ]);
    setProducts(productData.products || []); setCategories(productData.categories || []); setOffers(offerData.offers || []);
    setOrders(orderData.orders || []); setCoupons(couponData.coupons || []); setSettings(settingsData);
  }, []);

  useEffect(() => { load().catch((reason) => setError(reason instanceof Error ? reason.message : "تعذر تحميل لوحة الإدارة.")).finally(() => setLoading(false)); }, [load]);

  const filteredProducts = useMemo(() => products.filter((product) => `${product.nameAr} ${product.nameEn} ${product.legacyId} ${product.category?.nameAr || ""}`.toLowerCase().includes(search.trim().toLowerCase())), [products, search]);
  const filteredOffers = useMemo(() => offers.filter((offer) => `${offer.title} ${offer.productName} ${offer.packageName}`.toLowerCase().includes(search.trim().toLowerCase())), [offers, search]);
  const filteredOrders = useMemo(() => orders.filter((order) => `${order.number} ${order.customerName} ${order.phone} ${order.status}`.toLowerCase().includes(search.trim().toLowerCase())), [orders, search]);
  const filteredCoupons = useMemo(() => coupons.filter((coupon) => `${coupon.code} ${coupon.type}`.toLowerCase().includes(search.trim().toLowerCase())), [coupons, search]);

  async function uploadImage(file: File) {
    const compressed = await compressImage(file);
    const form = new FormData(); form.append("file", compressed);
    const result = await api<{ id: string }>("/api/uploads", { method: "POST", body: form });
    return result.id;
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!productDraft) return;
    if (!productDraft.nameAr.trim() || !productDraft.packages.length || productDraft.packages.some((item) => !item.nameAr.trim() || !Number.isFinite(Number(item.price)) || Number(item.price) <= 0)) { setError("أكمل اسم المنتج وجميع الباقات والأسعار قبل الحفظ."); return; }
    setSaving(true); setError("");
    try {
      const body = { ...productDraft, packages: productDraft.packages.map((item) => ({ ...item, price: Number(item.price) })) };
      await api(productDraft.id ? `/api/admin/products/${productDraft.id}` : "/api/admin/products", { method: productDraft.id ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      setProductDraft(null); await load(); notify("تم حفظ بيانات المنتج والباقات بنجاح.");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر حفظ المنتج."); }
    finally { setSaving(false); }
  }

  async function deleteProduct(product: AdminProduct) {
    if (!window.confirm(`سيتم حذف «${product.nameAr}» وباقاته وعروضه المرتبطة. هل تريد المتابعة؟`)) return;
    try { await api(`/api/admin/products/${product.id}`, { method: "DELETE" }); await load(); notify("تم حذف المنتج."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر حذف المنتج."); }
  }

  function newProduct() {
    setProductDraft({ categoryId: categories[0]?.id || "", nameAr: "", nameEn: "", descriptionAr: "", descriptionEn: "", deliveryAr: "تسليم سريع", deliveryEn: "Fast delivery", requiresPlayerId: false, imageId: null, defaultImageId: null, fallbackImageUrl: null, active: true, sortOrder: products.length, packages: [{ nameAr: "", nameEn: "", price: "", imageId: null, active: true }] });
  }

  function editProduct(product: AdminProduct) {
    setProductDraft({ ...product, packages: product.packages.map((item) => ({ ...item, price: String(item.price) })) });
  }

  async function saveOffer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!offerDraft) return;
    setSaving(true); setError("");
    try {
      const body = { ...offerDraft, discountPrice: Number(offerDraft.discountPrice), startsAt: new Date(offerDraft.startsAt).toISOString(), endsAt: new Date(offerDraft.endsAt).toISOString() };
      await api(offerDraft.id ? `/api/admin/offers/${offerDraft.id}` : "/api/admin/offers", { method: offerDraft.id ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      setOfferDraft(null); await load(); notify("تم حفظ العرض. سيظهر حسب فترة الصلاحية.");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر حفظ العرض."); }
    finally { setSaving(false); }
  }

  async function deleteOffer(offer: Offer) {
    if (!window.confirm(`حذف العرض «${offer.title}» نهائياً؟`)) return;
    try { await api(`/api/admin/offers/${offer.id}`, { method: "DELETE" }); await load(); notify("تم حذف العرض."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر حذف العرض."); }
  }

  async function toggleOffer(offer: Offer) {
    if (offer.active && !window.confirm(`إيقاف عرض «${offer.title}»؟`)) return;
    try { await api(`/api/admin/offers/${offer.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ active: !offer.active }) }); await load(); notify(offer.active ? "تم إيقاف العرض." : "تم تفعيل العرض."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر تحديث العرض."); }
  }

  async function updateOrder(order: Order, status: string) {
    if (status === "cancelled" && !window.confirm(`هل تريد إلغاء الطلب ${order.number}؟`)) return;
    try { await api("/api/admin/orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: order.id, status }) }); await load(); notify("تم تحديث حالة الطلب."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر تحديث الطلب."); }
  }

  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true); setError("");
    try { await api("/api/admin/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(settings) }); notify("تم حفظ إعدادات المتجر."); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر حفظ الإعدادات."); }
    finally { setSaving(false); }
  }

  async function saveCoupon(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!couponDraft) return; setSaving(true); setError("");
    try {
      const body = { ...couponDraft, value: Number(couponDraft.value), minPurchase: Number(couponDraft.minPurchase || 0), maxDiscount: couponDraft.maxDiscount ? Number(couponDraft.maxDiscount) : null, maxUses: couponDraft.maxUses ? Number(couponDraft.maxUses) : null, categoryId: couponDraft.categoryId || null, startsAt: couponDraft.startsAt ? new Date(couponDraft.startsAt).toISOString() : null, endsAt: couponDraft.endsAt ? new Date(couponDraft.endsAt).toISOString() : null };
      await api(couponDraft.id ? `/api/admin/coupons/${couponDraft.id}` : "/api/admin/coupons", { method: couponDraft.id ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      setCouponDraft(null); await load(); notify("تم حفظ كود الخصم.");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر حفظ الكوبون."); }
    finally { setSaving(false); }
  }

  async function deleteCoupon(coupon: Coupon) {
    if (!window.confirm(`حذف كود الخصم ${coupon.code} نهائياً؟`)) return;
    try { await api(`/api/admin/coupons/${coupon.id}`, { method: "DELETE" }); await load(); notify("تم حذف كود الخصم."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر حذف الكود."); }
  }

  async function toggleCoupon(coupon: Coupon) {
    if (coupon.active && !window.confirm(`إيقاف كود الخصم ${coupon.code}؟`)) return;
    try { await api(`/api/admin/coupons/${coupon.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ active: !coupon.active }) }); await load(); notify(coupon.active ? "تم إيقاف الكود." : "تم تفعيل الكود."); }
    catch (reason) { notify(reason instanceof Error ? reason.message : "تعذر تحديث الكود."); }
  }

  async function signOut() { await fetch("/api/auth/logout", { method: "POST" }); router.replace("/admin/login"); router.refresh(); }

  if (loading) return <div className="admin-shell"><div className="no-results">جارٍ تحميل لوحة الإدارة...</div></div>;
  const activeOffers = offers.filter((item) => item.active && new Date(item.startsAt) <= new Date() && new Date(item.endsAt) >= new Date()).length;
  const pendingOrders = orders.filter((item) => !["delivered", "cancelled"].includes(item.status)).length;

  return <div className="admin-shell">
    <div className="admin-topbar"><div><span className="eyebrow">VEXORA ADMIN</span><h1>إدارة متجرك، ببساطة.</h1><p>مرحباً بك في لوحة تحكم VEXORA · كل التغييرات تحفظ مباشرة.</p></div><div className="admin-actions-inline"><Link className="button button-quiet button-small" href="/">عرض المتجر ↗</Link><button className="button button-outline button-small" onClick={signOut}>تسجيل الخروج</button></div></div>
    {error && <p className="form-error">{error}</p>}
    <div className="admin-layout">
      <aside className="admin-sidebar"><label className="search-field admin-search"><input type="search" aria-label="بحث سريع في لوحة الإدارة" placeholder="بحث سريع..." value={search} onChange={(event) => setSearch(event.target.value)} /></label><nav className="admin-nav" aria-label="أقسام الإدارة">{navigation.map((item) => <button key={item.id} type="button" className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><span className="nav-icon"><Icon name={item.icon} size={17} /></span>{item.label}</button>)}</nav></aside>
      <div className="admin-content">
        {section === "overview" && <Overview products={products} offers={offers} orders={orders} pendingOrders={pendingOrders} activeOffers={activeOffers} onSelect={setSection} />}
        {section === "products" && <ProductsSection products={filteredProducts} categories={categories} onAdd={newProduct} onEdit={editProduct} onDelete={deleteProduct} />}
        {section === "offers" && <OffersSection offers={filteredOffers} products={products} onAdd={() => setOfferDraft(makeOfferDraft(products))} onEdit={(item) => setOfferDraft({ id: item.id, title: item.title, description: item.description, productId: item.productId, packageId: item.packageId, imageId: item.imageId, discountPrice: String(item.discountPrice), startsAt: toLocalDateTime(item.startsAt), endsAt: toLocalDateTime(item.endsAt), active: item.active, sortOrder: item.sortOrder })} onDelete={deleteOffer} onToggle={toggleOffer} />}
        {section === "orders" && <OrdersSection orders={filteredOrders} onUpdate={updateOrder} />}
        {section === "coupons" && <CouponsSection coupons={filteredCoupons} onAdd={() => setCouponDraft(makeCouponDraft())} onEdit={(item) => setCouponDraft({ id: item.id, code: item.code, type: item.type, value: String(item.value), minPurchase: String(item.minPurchase), maxDiscount: item.maxDiscount === null ? "" : String(item.maxDiscount), categoryId: item.categoryId || "", startsAt: item.startsAt ? toLocalDateTime(item.startsAt) : "", endsAt: item.endsAt ? toLocalDateTime(item.endsAt) : "", active: item.active, maxUses: item.maxUses === null ? "" : String(item.maxUses) })} onDelete={deleteCoupon} onToggle={toggleCoupon} />}
        {section === "settings" && <SettingsSection settings={settings} setSettings={setSettings} onSave={saveSettings} saving={saving} search={search} />}
      </div>
    </div>

    {productDraft && <div className="admin-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setProductDraft(null); }}><div className="admin-modal wide" role="dialog" aria-modal="true" aria-labelledby="product-editor-title"><div className="admin-modal-title"><h2 id="product-editor-title">{productDraft.id ? "تعديل المنتج والباقات" : "إضافة منتج جديد"}</h2><button type="button" className="icon-button" aria-label="إغلاق" onClick={() => setProductDraft(null)}><Icon name="close" /></button></div><form onSubmit={saveProduct}>
      <div className="form-grid"><div className="field"><label className="form-label">اسم المنتج (عربي)</label><input className="input" required value={productDraft.nameAr} onChange={(event) => setProductDraft({ ...productDraft, nameAr: event.target.value })} /></div><div className="field"><label className="form-label">اسم المنتج (English)</label><input className="input" value={productDraft.nameEn} onChange={(event) => setProductDraft({ ...productDraft, nameEn: event.target.value })} /></div><div className="field"><label className="form-label">التصنيف</label><select className="select" value={productDraft.categoryId} onChange={(event) => setProductDraft({ ...productDraft, categoryId: event.target.value })}>{categories.map((category) => <option key={category.id} value={category.id}>{category.icon} {category.nameAr}</option>)}</select></div><div className="field"><label className="form-label">وقت التسليم</label><input className="input" value={productDraft.deliveryAr} onChange={(event) => setProductDraft({ ...productDraft, deliveryAr: event.target.value })} /></div></div>
      <div className="form-grid"><div className="field"><label className="form-label">وصف المنتج (عربي)</label><textarea className="textarea" value={productDraft.descriptionAr} onChange={(event) => setProductDraft({ ...productDraft, descriptionAr: event.target.value })} /></div><div className="field"><label className="form-label">الوصف (English)</label><textarea className="textarea" value={productDraft.descriptionEn} onChange={(event) => setProductDraft({ ...productDraft, descriptionEn: event.target.value })} /></div></div>
      <MediaField label="الصورة الأساسية للمنتج" imageId={productDraft.imageId} fallback={productDraft.defaultImageId ? `/api/images/${productDraft.defaultImageId}` : productDraft.fallbackImageUrl} upload={uploadImage} onChange={(imageId) => setProductDraft({ ...productDraft, imageId })} />
      <label style={{ display: "flex", alignItems: "center", gap: 9, margin: "13px 0", color: "#c8c2b6", fontSize: 12 }}><input type="checkbox" checked={productDraft.requiresPlayerId} onChange={(event) => setProductDraft({ ...productDraft, requiresPlayerId: event.target.checked })} />يتطلب Player ID عند الطلب</label>
      <label style={{ display: "flex", alignItems: "center", gap: 9, margin: "13px 0", color: "#c8c2b6", fontSize: 12 }}><input type="checkbox" checked={productDraft.active} onChange={(event) => setProductDraft({ ...productDraft, active: event.target.checked })} />المنتج متاح في المتجر</label>
      <div className="admin-panel-heading" style={{ marginTop: 20 }}><div><h2>باقات المنتج</h2><p>صورة كل باقة مستقلة عن صورة المنتج الأساسية.</p></div><button type="button" className="button button-outline button-small" onClick={() => setProductDraft({ ...productDraft, packages: [...productDraft.packages, { nameAr: "", nameEn: "", price: "", imageId: null, active: true }] })}><Icon name="plus" size={15} /> إضافة باقة</button></div>
      {productDraft.packages.map((item, index) => <div className="package-editor" key={item.id || `new-${index}`}><div className="package-editor-head"><strong>الباقة {index + 1}{item.legacyIndex !== undefined ? ` · الرمز ${item.legacyIndex}` : " · جديدة"}</strong><button type="button" className="button button-danger button-small" onClick={() => { if (item.id && !window.confirm("حذف هذه الباقة سيحذف العرض المرتبط بها. متابعة؟")) return; setProductDraft({ ...productDraft, packages: productDraft.packages.filter((_, itemIndex) => itemIndex !== index) }); }}>حذف الباقة</button></div><div className="package-editor-grid"><div className="field"><label className="form-label">اسم الباقة (عربي)</label><input className="input" required value={item.nameAr} onChange={(event) => setProductDraft({ ...productDraft, packages: productDraft.packages.map((pack, itemIndex) => itemIndex === index ? { ...pack, nameAr: event.target.value } : pack) })} /></div><div className="field"><label className="form-label">اسم الباقة (English)</label><input className="input" value={item.nameEn} onChange={(event) => setProductDraft({ ...productDraft, packages: productDraft.packages.map((pack, itemIndex) => itemIndex === index ? { ...pack, nameEn: event.target.value } : pack) })} /></div><div className="field"><label className="form-label">السعر (ج.م)</label><input className="input" type="number" min="0.01" step="0.01" required value={item.price} onChange={(event) => setProductDraft({ ...productDraft, packages: productDraft.packages.map((pack, itemIndex) => itemIndex === index ? { ...pack, price: event.target.value } : pack) })} /></div></div><MediaField label={`صورة الباقة ${index + 1}`} imageId={item.imageId} fallback={productDraft.imageId ? `/api/images/${productDraft.imageId}` : productDraft.defaultImageId ? `/api/images/${productDraft.defaultImageId}` : productDraft.fallbackImageUrl} upload={uploadImage} onChange={(imageId) => setProductDraft({ ...productDraft, packages: productDraft.packages.map((pack, itemIndex) => itemIndex === index ? { ...pack, imageId } : pack) })} /><label style={{ display: "inline-flex", alignItems: "center", gap: 7, marginTop: 9, fontSize: 10, color: "var(--muted)" }}><input type="checkbox" checked={item.active} onChange={(event) => setProductDraft({ ...productDraft, packages: productDraft.packages.map((pack, itemIndex) => itemIndex === index ? { ...pack, active: event.target.checked } : pack) })} />متاحة للشراء</label></div>)}
      {error && <p className="form-error">{error}</p>}<div className="admin-modal-actions"><button type="button" className="button button-quiet" onClick={() => setProductDraft(null)}>إلغاء</button><button type="submit" className="button button-gold" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ المنتج والباقات"}</button></div>
    </form></div></div>}

    {offerDraft && <OfferModal draft={offerDraft} products={products} onChange={setOfferDraft} onClose={() => setOfferDraft(null)} onSave={saveOffer} upload={uploadImage} saving={saving} error={error} />}
    {couponDraft && <CouponModal draft={couponDraft} categories={categories} onChange={setCouponDraft} onClose={() => setCouponDraft(null)} onSave={saveCoupon} saving={saving} error={error} />}
  </div>;
}

function Overview({ products, offers, orders, pendingOrders, activeOffers, onSelect }: { products: AdminProduct[]; offers: Offer[]; orders: Order[]; pendingOrders: number; activeOffers: number; onSelect: (section: Section) => void }) {
  const totalValue = orders.filter((item) => item.status !== "cancelled").reduce((sum, item) => sum + item.total, 0);
  return <><div className="stats-grid"><div className="stat-card"><span>المنتجات</span><strong>{products.length}</strong></div><div className="stat-card"><span>العروض الفعّالة</span><strong>{activeOffers}</strong></div><div className="stat-card"><span>طلبات تحتاج متابعة</span><strong>{pendingOrders}</strong></div><div className="stat-card"><span>قيمة الطلبات المسجلة</span><strong style={{ fontSize: 17 }}>{formatMoney(totalValue)}</strong></div></div><section className="admin-panel"><div className="admin-panel-heading"><div><h2>الوصول السريع</h2><p>الأقسام الأكثر استخداماً في متجرك.</p></div></div><div className="admin-actions-inline"><button className="button button-outline" onClick={() => onSelect("products")}>إدارة المنتجات والباقات</button><button className="button button-outline" onClick={() => onSelect("offers")}>إنشاء عرض حصري</button><button className="button button-outline" onClick={() => onSelect("orders")}>متابعة الطلبات</button></div></section><section className="admin-panel"><div className="admin-panel-heading"><div><h2>أحدث الطلبات</h2><p>آخر خمسة طلبات مسجلة.</p></div><button className="button button-quiet button-small" onClick={() => onSelect("orders")}>كل الطلبات</button></div>{orders.length ? <div className="admin-list">{orders.slice(0, 5).map((order) => <div className="admin-row" key={order.id}><div><strong>{order.number} · {order.customerName}</strong><small>{new Date(order.createdAt).toLocaleString("ar-EG")}</small></div><span className="status-badge">{statusLabel(order.status)}</span><strong>{formatMoney(order.total)}</strong><div className="admin-row-actions"><span>{order.phone}</span></div></div>)}</div> : <div className="empty-panel">ستظهر الطلبات الجديدة هنا تلقائياً.</div>}</section><section className="admin-panel"><div className="admin-panel-heading"><div><h2>العروض الحصرية</h2><p>تظهر للعميل قبل المنتجات على الصفحة الرئيسية.</p></div><span className="status-badge">{offers.length} عرض</span></div><div className="admin-hint">نسبة الخصم محسوبة دائماً من السعر الحالي للباقة، ولا تتراكم خصومات العروض.</div></section></>;
}

function ProductsSection({ products, categories, onAdd, onEdit, onDelete }: { products: AdminProduct[]; categories: Category[]; onAdd: () => void; onEdit: (product: AdminProduct) => void; onDelete: (product: AdminProduct) => void }) {
  return <section className="admin-panel"><div className="admin-panel-heading"><div><h2>المنتجات والباقات</h2><p>تعديل الأسعار والوصف والصور الأساسية وصور الباقات بشكل مستقل.</p></div><button className="button button-gold" onClick={onAdd}><Icon name="plus" size={16} /> منتج جديد</button></div>{products.length ? <div className="admin-list">{products.map((product) => <div className="admin-row" key={product.id}><div><strong>{product.nameAr}</strong><small>#{product.legacyId} · {categories.find((item) => item.id === product.categoryId)?.nameAr || product.categoryId} · {product.packages.length} باقات</small></div><span className={`status-badge ${product.active ? "success" : "muted"}`}>{product.active ? "متاح" : "مخفي"}</span><strong>{product.packages.length ? `من ${formatMoney(Math.min(...product.packages.map((item) => item.price)))}` : "بلا باقات"}</strong><div className="admin-row-actions"><button className="button button-quiet button-small" onClick={() => onEdit(product)}><Icon name="edit" size={13} /> تعديل</button><button className="button button-danger button-small" onClick={() => onDelete(product)}><Icon name="trash" size={13} /> حذف</button></div></div>)}</div> : <div className="empty-panel">لا توجد منتجات مطابقة للبحث.</div>}</section>;
}

function OffersSection({ offers, products, onAdd, onEdit, onDelete, onToggle }: { offers: Offer[]; products: AdminProduct[]; onAdd: () => void; onEdit: (offer: Offer) => void; onDelete: (offer: Offer) => void; onToggle: (offer: Offer) => void }) {
  return <section className="admin-panel"><div className="admin-panel-heading"><div><h2>العروض الحصرية</h2><p>اربط كل عرض بباقة واحدة. يمنع النظام التداخل على الباقة نفسها.</p></div><button className="button button-gold" onClick={onAdd} disabled={!products.some((item) => item.packages.length)}><Icon name="plus" size={16} /> إضافة عرض</button></div>{offers.length ? <div className="admin-list">{offers.map((offer) => { const percent = offer.basePrice ? Math.round((1 - offer.discountPrice / offer.basePrice) * 100) : 0; return <div key={offer.id} className="admin-row"><div><strong>{offer.title}</strong><small>{offer.productName} · {offer.packageName}</small></div><span className={`status-badge ${offer.active ? "success" : "muted"}`}>{offer.active ? "مفعّل" : "متوقف"} · −{percent}%</span><strong>{formatMoney(offer.discountPrice)} <small className="price-old">{formatMoney(offer.basePrice)}</small></strong><div className="admin-row-actions"><button className="button button-quiet button-small" onClick={() => onEdit(offer)}>تعديل</button><button className="button button-outline button-small" onClick={() => onToggle(offer)}>{offer.active ? "إيقاف" : "تفعيل"}</button><button className="button button-danger button-small" onClick={() => onDelete(offer)}>حذف</button></div></div>; })}</div> : <div className="empty-panel">لا توجد عروض بعد. أنشئ عرضاً مرتبطاً بسعر باقة حقيقي.</div>}</section>;
}

function OrdersSection({ orders, onUpdate }: { orders: Order[]; onUpdate: (order: Order, status: string) => void }) {
  return <section className="admin-panel"><div className="admin-panel-heading"><div><h2>إدارة الطلبات</h2><p>تحديث حالة الطلب يظهر مباشرة في صفحة التتبع.</p></div><span className="status-badge">{orders.length} طلب</span></div>{orders.length ? <div className="admin-list">{orders.map((order) => <article key={order.id} className="admin-row" style={{ gridTemplateColumns: "minmax(150px,1.4fr) minmax(90px,.8fr) minmax(80px,.6fr) auto" }}><div><strong>{order.number} · {order.customerName}</strong><small>{order.phone}{order.email ? ` · ${order.email}` : ""}<br />{order.items.map((item) => `${item.productName} (${item.packageName}) × ${item.quantity}`).join("، ")}</small></div><span className="status-badge">{statusLabel(order.status)}</span><strong>{formatMoney(order.total)}</strong><div className="admin-row-actions"><select aria-label={`تحديث حالة الطلب ${order.number}`} className="select" style={{ width: 140, minHeight: 34, padding: "4px 8px", fontSize: 10 }} value={order.status} onChange={(event) => onUpdate(order, event.target.value)}>{orderStatuses.map((status) => <option key={status} value={status}>{statusLabel(status)}</option>)}</select></div></article>)}</div> : <div className="empty-panel">لا توجد طلبات مسجلة بعد.</div>}</section>;
}

function CouponsSection({ coupons, onAdd, onEdit, onDelete, onToggle }: { coupons: Coupon[]; onAdd: () => void; onEdit: (coupon: Coupon) => void; onDelete: (coupon: Coupon) => void; onToggle: (coupon: Coupon) => void }) {
  return <section className="admin-panel"><div className="admin-panel-heading"><div><h2>أكواد الخصم</h2><p>الخصم يطبق بعد عروض الباقات ولا يمكن أن يتجاوز السعر النهائي.</p></div><button className="button button-gold" onClick={onAdd}><Icon name="plus" size={16} /> كود جديد</button></div>{coupons.length ? <div className="admin-list">{coupons.map((coupon) => <div className="admin-row" key={coupon.id}><div><strong>{coupon.code}</strong><small>استخدم {coupon.usedCount}{coupon.maxUses ? ` من ${coupon.maxUses}` : " مرة"}</small></div><span className={`status-badge ${coupon.active ? "success" : "muted"}`}>{coupon.active ? "مفعّل" : "متوقف"}</span><strong>{coupon.type === "percent" ? `${coupon.value}%` : formatMoney(coupon.value)}</strong><div className="admin-row-actions"><button className="button button-quiet button-small" onClick={() => onEdit(coupon)}>تعديل</button><button className="button button-outline button-small" onClick={() => onToggle(coupon)}>{coupon.active ? "إيقاف" : "تفعيل"}</button><button className="button button-danger button-small" onClick={() => onDelete(coupon)}>حذف</button></div></div>)}</div> : <div className="empty-panel">لا توجد أكواد خصم مسجلة.</div>}</section>;
}

function SettingsSection({ settings, setSettings, onSave, saving, search }: { settings: Settings; setSettings: (value: Settings) => void; onSave: (event: FormEvent<HTMLFormElement>) => void; saving: boolean; search: string }) {
  const query = search.trim().toLowerCase();
  const matches = (term: string) => !query || term.toLowerCase().includes(query);
  const visible = matches("tagline الهوية وصف الموقع") || matches("whatsapp واتساب الدعم") || matches("paymentDetails الدفع بيانات التحويل");
  return <section className="admin-panel"><div className="admin-panel-heading"><div><h2>إعدادات المتجر</h2><p>معلومات التواصل والدفع التي تظهر عند تجهيز الطلب.</p></div></div>{visible ? <form onSubmit={onSave} style={{ maxWidth: 700 }}><div className="field"><label className="form-label">العبارة التعريفية</label><input className="input" value={settings.tagline} onChange={(event) => setSettings({ ...settings, tagline: event.target.value })} maxLength={200} /></div><div className="field"><label className="form-label">رقم واتساب الدولي</label><input className="input" inputMode="tel" dir="ltr" value={settings.whatsappNumber} onChange={(event) => setSettings({ ...settings, whatsappNumber: event.target.value })} placeholder="201xxxxxxxxx" /><span className="admin-hint">أدخل الرقم مع مفتاح الدولة من دون علامة + أو فواصل إن أمكن.</span></div><div className="field"><label className="form-label">تعليمات الدفع والتحويل</label><textarea className="textarea" value={settings.paymentDetails} onChange={(event) => setSettings({ ...settings, paymentDetails: event.target.value })} placeholder="أضف بيانات فودافون كاش أو إنستاباي أو الحساب البنكي..." /></div><button className="button button-gold" type="submit" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ الإعدادات"}</button></form> : <div className="empty-panel">لا توجد إعدادات مطابقة للبحث.</div>}</section>;
}

function MediaField({ label, imageId, fallback, upload, onChange }: { label: string; imageId: string | null; fallback?: string | null; upload: (file: File) => Promise<string>; onChange: (id: string | null) => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const source = imageId ? `/api/images/${imageId}` : fallback || "";
  async function choose(file?: File) {
    if (!file) return; setBusy(true); setError("");
    try { onChange(await upload(file)); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر رفع الصورة."); }
    finally { setBusy(false); }
  }
  return <div className="field"><label className="form-label">{label}</label><div className="admin-image-edit"><div className="admin-image-preview">{source ? <img src={source} alt={label} /> : <div className="product-image-placeholder"><Icon name="image" /></div>}</div><div><div className="admin-image-actions"><label className="button button-outline button-small" style={{ cursor: "pointer" }}>{busy ? "جارٍ تجهيز الصورة..." : imageId ? "استبدال الصورة" : "رفع صورة من الجهاز"}<input type="file" accept="image/jpeg,image/png,image/webp" hidden disabled={busy} onChange={(event) => { void choose(event.target.files?.[0]); event.currentTarget.value = ""; }} /></label>{imageId && <button type="button" className="button button-quiet button-small" onClick={() => onChange(null)}>استعادة الافتراضي / حذف</button>}</div><span className="admin-hint">JPG أو PNG أو WEBP · الحد 5MB · يجري ضغطها تلقائياً قبل الحفظ.</span>{error && <span className="field-error">{error}</span>}</div></div></div>;
}

function OfferModal({ draft, products, onChange, onClose, onSave, upload, saving, error }: { draft: OfferDraft; products: AdminProduct[]; onChange: (draft: OfferDraft) => void; onClose: () => void; onSave: (event: FormEvent<HTMLFormElement>) => void; upload: (file: File) => Promise<string>; saving: boolean; error: string }) {
  const product = products.find((item) => item.id === draft.productId);
  const pack = product?.packages.find((item) => item.id === draft.packageId);
  const fallback = draft.imageId ? null : pack?.imageId ? `/api/images/${pack.imageId}` : product?.imageId ? `/api/images/${product.imageId}` : product?.defaultImageId ? `/api/images/${product.defaultImageId}` : product?.fallbackImageUrl;
  return <div className="admin-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="offer-modal-title"><div className="admin-modal-title"><h2 id="offer-modal-title">{draft.id ? "تعديل العرض" : "إضافة عرض حصري"}</h2><button type="button" className="icon-button" aria-label="إغلاق" onClick={onClose}><Icon name="close" /></button></div><form onSubmit={onSave}><div className="field"><label className="form-label">عنوان العرض</label><input className="input" required value={draft.title} onChange={(event) => onChange({ ...draft, title: event.target.value })} /></div><div className="field"><label className="form-label">وصف مختصر</label><textarea className="textarea" value={draft.description} onChange={(event) => onChange({ ...draft, description: event.target.value })} /></div><div className="form-grid"><div className="field"><label className="form-label">المنتج</label><select className="select" required value={draft.productId} onChange={(event) => { const next = products.find((item) => item.id === event.target.value); onChange({ ...draft, productId: event.target.value, packageId: next?.packages[0]?.id || "" }); }}>{products.map((item) => <option key={item.id} value={item.id}>{item.nameAr}</option>)}</select></div><div className="field"><label className="form-label">الباقة المرتبطة</label><select className="select" required value={draft.packageId} onChange={(event) => onChange({ ...draft, packageId: event.target.value })}>{product?.packages.map((item) => <option key={item.id} value={item.id}>{item.nameAr} · {formatMoney(item.price)}</option>)}</select></div><div className="field"><label className="form-label">سعر العرض بعد الخصم (ج.م)</label><input className="input" type="number" required step="0.01" min="0.01" max={pack ? pack.price - .01 : undefined} value={draft.discountPrice} onChange={(event) => onChange({ ...draft, discountPrice: event.target.value })} />{pack && <span className="admin-hint">السعر الحالي {formatMoney(pack.price)} — لا يمكن أن يكون العرض أعلى منه.</span>}</div><div className="field"><label className="form-label">ترتيب الظهور</label><input className="input" type="number" value={draft.sortOrder} onChange={(event) => onChange({ ...draft, sortOrder: Number(event.target.value) })} /></div><div className="field"><label className="form-label">بداية العرض</label><input className="input" type="datetime-local" required value={draft.startsAt} onChange={(event) => onChange({ ...draft, startsAt: event.target.value })} /></div><div className="field"><label className="form-label">نهاية العرض</label><input className="input" type="datetime-local" required value={draft.endsAt} onChange={(event) => onChange({ ...draft, endsAt: event.target.value })} /></div></div><MediaField label="صورة خاصة بالعرض" imageId={draft.imageId} fallback={fallback} upload={upload} onChange={(imageId) => onChange({ ...draft, imageId })} /><label style={{ display: "flex", gap: 8, margin: "13px 0", fontSize: 11 }}><input type="checkbox" checked={draft.active} onChange={(event) => onChange({ ...draft, active: event.target.checked })} />تفعيل العرض</label>{error && <p className="form-error">{error}</p>}<div className="admin-modal-actions"><button type="button" className="button button-quiet" onClick={onClose}>إلغاء</button><button className="button button-gold" type="submit" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ العرض"}</button></div></form></div></div>;
}

function CouponModal({ draft, categories, onChange, onClose, onSave, saving, error }: { draft: CouponDraft; categories: Category[]; onChange: (draft: CouponDraft) => void; onClose: () => void; onSave: (event: FormEvent<HTMLFormElement>) => void; saving: boolean; error: string }) {
  return <div className="admin-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="coupon-modal-title"><div className="admin-modal-title"><h2 id="coupon-modal-title">{draft.id ? "تعديل كود الخصم" : "إنشاء كود خصم"}</h2><button type="button" className="icon-button" aria-label="إغلاق" onClick={onClose}><Icon name="close" /></button></div><form onSubmit={onSave}><div className="form-grid"><div className="field"><label className="form-label">الكود</label><input className="input" required minLength={3} value={draft.code} onChange={(event) => onChange({ ...draft, code: event.target.value.toUpperCase() })} /></div><div className="field"><label className="form-label">نوع الخصم</label><select className="select" value={draft.type} onChange={(event) => onChange({ ...draft, type: event.target.value })}><option value="percent">نسبة مئوية</option><option value="fixed">مبلغ ثابت</option></select></div><div className="field"><label className="form-label">قيمة الخصم</label><input className="input" type="number" required min="0.01" step="0.01" max={draft.type === "percent" ? 100 : undefined} value={draft.value} onChange={(event) => onChange({ ...draft, value: event.target.value })} /></div><div className="field"><label className="form-label">الحد الأدنى للطلب (ج.م)</label><input className="input" type="number" min="0" step="0.01" value={draft.minPurchase} onChange={(event) => onChange({ ...draft, minPurchase: event.target.value })} /></div><div className="field"><label className="form-label">الحد الأقصى للخصم (اختياري)</label><input className="input" type="number" min="0.01" step="0.01" value={draft.maxDiscount} onChange={(event) => onChange({ ...draft, maxDiscount: event.target.value })} /></div><div className="field"><label className="form-label">التصنيف (اختياري)</label><select className="select" value={draft.categoryId} onChange={(event) => onChange({ ...draft, categoryId: event.target.value })}><option value="">كل التصنيفات</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.nameAr}</option>)}</select></div><div className="field"><label className="form-label">بداية الصلاحية</label><input className="input" type="datetime-local" value={draft.startsAt} onChange={(event) => onChange({ ...draft, startsAt: event.target.value })} /></div><div className="field"><label className="form-label">نهاية الصلاحية</label><input className="input" type="datetime-local" value={draft.endsAt} onChange={(event) => onChange({ ...draft, endsAt: event.target.value })} /></div><div className="field"><label className="form-label">عدد الاستخدامات الأقصى</label><input className="input" type="number" min="1" value={draft.maxUses} onChange={(event) => onChange({ ...draft, maxUses: event.target.value })} /></div></div><label style={{ display: "flex", gap: 8, margin: "8px 0 14px", fontSize: 11 }}><input type="checkbox" checked={draft.active} onChange={(event) => onChange({ ...draft, active: event.target.checked })} />الكود مفعّل</label>{error && <p className="form-error">{error}</p>}<div className="admin-modal-actions"><button type="button" className="button button-quiet" onClick={onClose}>إلغاء</button><button className="button button-gold" type="submit" disabled={saving}>{saving ? "جارٍ الحفظ..." : "حفظ الكود"}</button></div></form></div></div>;
}

function makeOfferDraft(products: AdminProduct[]): OfferDraft {
  const first = products.find((item) => item.packages.length)?.packages[0];
  const product = products.find((item) => item.packages.length);
  return { title: "", description: "", productId: product?.id || "", packageId: first?.id || "", imageId: null, discountPrice: "", startsAt: toLocalDateTime(new Date()), endsAt: toLocalDateTime(new Date(Date.now() + 7 * 86400000)), active: true, sortOrder: 0 };
}
function makeCouponDraft(): CouponDraft { return { code: "", type: "percent", value: "", minPurchase: "0", maxDiscount: "", categoryId: "", startsAt: "", endsAt: "", active: true, maxUses: "" }; }
function statusLabel(status: string) { return ({ received: "تم استلام الطلب", paid: "تم تأكيد الدفع", processing: "قيد التنفيذ", ready: "جاهز للتسليم", delivered: "تم التسليم", cancelled: "تم إلغاء الطلب" } as Record<string, string>)[status] || status; }
