"use client";

import Link from "next/link";
import { useMemo, useState, type FormEvent } from "react";
import type { PublicProduct } from "@/lib/store";
import { formatMoney } from "@/lib/money";

type Category = { id: string; icon: string; name: { ar: string; en: string } };
type Offer = { id: string; title: string; description: string; productId: number; packageIndex: number; packageId: string; productName: string; packageName: string; image: string | null; originalPrice: number; discountPrice: number; discountPercent: number; startsAt: string; endsAt: string };
type StoreData = { categories: Category[]; products: PublicProduct[]; offers: Offer[]; banner: { title: string; subtitle: string } };

export function Storefront({ data }: { data: StoreData }) {
  const [activeCategory, setActiveCategory] = useState("all");
  const [search, setSearch] = useState("");
  const products = useMemo(() => data.products.filter((product) => {
    const categoryMatch = activeCategory === "all" || product.category === activeCategory;
    const term = search.trim().toLocaleLowerCase();
    const searchMatch = !term || `${product.name.ar} ${product.name.en} ${product.description.ar} ${product.description.en}`.toLocaleLowerCase().includes(term);
    return categoryMatch && searchMatch;
  }), [data.products, activeCategory, search]);

  return <>
    <section className="hero">
      <div className="container hero-content">
        <span className="eyebrow">YOUR DIGITAL WORLD</span>
        <h1>{data.banner.title}</h1>
        <p>{data.banner.subtitle} تجربة سلسة، تسليم سريع، وأسعار واضحة من البداية.</p>
        <div className="hero-actions"><Link className="button button-gold" href="/#store">تصفّح المتجر <span aria-hidden="true">←</span></Link><Link className="button button-quiet" href="/#tracking">تتبّع طلبك</Link></div>
        <div className="hero-meta"><span>منتجات أصلية</span><span>دفع محلي آمن</span><span>خدمة سريعة</span></div>
      </div>
    </section>

    <section id="offers" className="container section offer-section">
      <div className="offer-banner">
        <div className="section-heading">
          <div><span className="eyebrow">LIMITED TIME</span><h2>EXCLUSIVE OFFERS</h2><p>عروض حصرية لفترة محدودة — خصومات حقيقية على باقات المتجر.</p></div>
          {data.offers.length > 0 && <span className="section-count">{data.offers.length} {data.offers.length === 1 ? "عرض متاح" : "عروض متاحة"}</span>}
        </div>
        {data.offers.length > 0 ? <div className="offer-grid">{data.offers.map((offer) => <OfferCard key={offer.id} offer={offer} />)}</div> : <div className="no-results">العروض الحصرية الجديدة ستظهر هنا قريباً.</div>}
      </div>
    </section>

    <section id="store" className="container section">
      <div className="section-heading"><div><span className="eyebrow">THE STORE</span><h2>المنتجات</h2><p>اختر منتجك وباقتك، وستظهر لك التفاصيل والسعر بوضوح.</p></div><span className="section-count">{data.products.length} منتج</span></div>
      <div className="store-tools">
        <label className="search-field"><input type="search" aria-label="ابحث عن منتج" placeholder="ابحث عن منتج..." value={search} onChange={(event) => setSearch(event.target.value)} /></label>
        <div className="filter-pills" role="group" aria-label="تصفية حسب التصنيف">
          <button type="button" className={`pill ${activeCategory === "all" ? "active" : ""}`} onClick={() => setActiveCategory("all")}>الكل</button>
          {data.categories.map((category) => <button key={category.id} type="button" className={`pill ${activeCategory === category.id ? "active" : ""}`} onClick={() => setActiveCategory(category.id)}>{category.icon} {category.name.ar}</button>)}
        </div>
      </div>
      {products.length ? <div className="product-grid">{products.map((product) => <ProductCard key={product.dbId} product={product} categoryName={data.categories.find((category) => category.id === product.category)?.name.ar || "منتجات رقمية"} />)}</div> : <div className="no-results">{data.products.length ? "لا توجد نتائج مطابقة لبحثك." : "الكتالوج جاهز لإضافة المنتجات من لوحة الإدارة."}</div>}
    </section>

    <section className="container section">
      <div className="section-heading"><div><span className="eyebrow">THE VEXORA STANDARD</span><h2>تسوّق بثقة</h2></div></div>
      <div className="feature-grid">
        <div className="feature-card"><span className="feature-icon">✦</span><strong>منتجات أصلية</strong><p>اختيارات رقمية موثوقة بعناية.</p></div>
        <div className="feature-card"><span className="feature-icon">◷</span><strong>تسليم سريع</strong><p>الوقت المتوقع موضّح لكل منتج.</p></div>
        <div className="feature-card"><span className="feature-icon">◇</span><strong>دفع محلي</strong><p>فودافون كاش وإنستاباي وتحويل بنكي.</p></div>
      </div>
    </section>

    <TrackingSection />
  </>;
}

function ProductCard({ product, categoryName }: { product: PublicProduct; categoryName: string }) {
  const available = product.packages.filter((item) => item.price > 0);
  const lowest = available.reduce<{ price: number; old?: number } | null>((best, item) => {
    const price = item.offer?.discountPrice ?? item.price;
    return !best || price < best.price ? { price, old: item.offer ? item.price : undefined } : best;
  }, null);
  return <article className="product-card">
    <Link href={`/products/${product.id}`} className="product-card-link" aria-label={`عرض ${product.name.ar}`}>
      <div className="product-image">{product.image ? <img src={product.image} alt={product.name.ar} loading="lazy" /> : <span className="product-image-placeholder">✧</span>}{product.packages.some((item) => item.offer) && <span className="discount-badge">عرض</span>}</div>
      <div className="product-card-body"><span className="product-category">{categoryName}</span><h3>{product.name.ar}</h3><div className="product-card-meta"><span>{product.delivery.ar}</span><strong>{lowest ? <>{lowest.old && <small className="price-old">{formatMoney(lowest.old)}</small>}{formatMoney(lowest.price)}<span className="from">من</span></> : "السعر عند الاختيار"}</strong></div></div>
    </Link>
    <div className="product-card-body" style={{ paddingTop: 0 }}><div className="product-quick"><span>{available.length} باقات متاحة</span><Link className="button button-outline" href={`/products/${product.id}`}>اختر باقتك <span aria-hidden="true">←</span></Link></div></div>
  </article>;
}

function OfferCard({ offer }: { offer: Offer }) {
  return <article className="offer-card">
    <div className="offer-image">{offer.image ? <img src={offer.image} alt={offer.title} loading="lazy" /> : <span className="offer-placeholder">✦</span>}<span className="discount-badge">-{offer.discountPercent}%</span></div>
    <div className="offer-body"><span className="offer-category">{offer.productName} · {offer.packageName}</span><h3>{offer.title}</h3><p>{offer.description || "عرض حصري لفترة محدودة."}</p><div className="offer-bottom"><div className="price-stack"><span className="price-old">{formatMoney(offer.originalPrice)}</span><strong className="price-current">{formatMoney(offer.discountPrice)}</strong></div><Link className="button button-gold" href={`/products/${offer.productId}?package=${offer.packageId}`}>اطلب الآن</Link></div></div>
  </article>;
}

function TrackingSection() {
  const [number, setNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ number: string; status: string; customerName: string; total: number; createdAt: string } | null>(null);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setResult(null); setBusy(true);
    try {
      const response = await fetch("/api/orders/track", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ number, phone }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "لم نعثر على طلب بهذه البيانات.");
      setResult(data);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "تعذر الاتصال. حاول مرة أخرى."); }
    finally { setBusy(false); }
  }
  return <section id="tracking" className="container section"><div className="tracking-panel"><div className="section-heading"><div><span className="eyebrow">ORDER TRACKING</span><h2>تتبّع طلبك</h2><p>أدخل رقم الطلب ورقم الهاتف للاطلاع على آخر تحديث.</p></div></div><form className="track-form" onSubmit={submit}><input className="input" value={number} onChange={(event) => setNumber(event.target.value)} placeholder="رقم الطلب" aria-label="رقم الطلب" required /><input className="input" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="رقم الهاتف" inputMode="tel" aria-label="رقم الهاتف" required /><button className="button button-gold" disabled={busy}>{busy ? "جارٍ البحث..." : "تتبّع الطلب"}</button></form>{error && <p className="form-error" style={{ marginTop: 13 }}>{error}</p>}{result && <div className="track-result"><strong>طلب {result.number}</strong> · <span className="status-badge">{statusLabel(result.status)}</span><p style={{ margin: "5px 0 0", color: "var(--muted)", fontSize: 11 }}>الإجمالي {formatMoney(result.total)} · {new Date(result.createdAt).toLocaleDateString("ar-EG")}</p></div>}</div></section>;
}

function statusLabel(status: string) {
  return ({ received: "تم استلام الطلب", paid: "تم تأكيد الدفع", processing: "قيد التنفيذ", ready: "جاهز للتسليم", delivered: "تم التسليم", cancelled: "تم إلغاء الطلب" } as Record<string, string>)[status] || status;
}
